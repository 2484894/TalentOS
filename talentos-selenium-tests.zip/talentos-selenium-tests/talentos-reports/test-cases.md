# TalentOS Selenium E2E — Test Case Documentation

**Project:** TalentOS Placement Portal  
**Frontend:** Angular (localhost:4200)  
**Test Framework:** Selenium WebDriver 4.18.1 + TestNG 7.9.0  
**Execution Date:** 2026-06-01  
**Total Test Cases:** 44  
**All Passed:** YES (44/44)

---

## Suite 1 — Login Tests
**File:** `LoginTest.java`  
**Pre-condition:** Angular running on localhost:4200

| TC ID | Test Method | What it tests | Steps | Expected Result | Status |
|-------|-------------|---------------|-------|-----------------|--------|
| TC-L-01 | `testLoginPageLoads` | Login page loads correctly | Navigate to /login | URL contains /login | PASS |
| TC-L-02 | `testBrandNameVisible` | TalentOS brand is shown | Navigate to /login, read brand text | Brand name = "TalentOS" | PASS |
| TC-L-03 | `testFormTitle` | Form heading is correct | Navigate to /login, read form title | Title = "Sign in" | PASS |
| TC-L-05 | `testStudentLoginRedirectsToDashboard` | Valid student login works | Enter student credentials, click submit | Redirected to /student/dashboard | PASS |
| TC-L-08 | `testRootRedirectsToLogin` | Root URL redirects unauthenticated user | Clear auth, navigate to / | Redirected to /login | PASS |

---

## Suite 2 — Register Tests
**File:** `RegisterTest.java`  
**Pre-condition:** Angular running on localhost:4200

| TC ID | Test Method | What it tests | Steps | Expected Result | Status |
|-------|-------------|---------------|-------|-----------------|--------|
| TC-R-01 | `testRegisterPageLoads` | Register page loads | Navigate to /register | URL contains /register | PASS |
| TC-R-02 | `testFormTitle` | Register form title is correct | Navigate to /register, read title | Title = "Create account" | PASS |
| TC-R-03 | `testStudentRoleCardSelectable` | Student role card is clickable | Click Student role card | No exception thrown | PASS |
| TC-R-04 | `testRecruiterRoleCardSelectable` | Recruiter role card is clickable | Click Recruiter role card | No exception thrown | PASS |
| TC-R-07 | `testSignInLinkNavigatesToLogin` | Sign-in link on register page works | Click "Sign in" link | Navigated to /login | PASS |

---

## Suite 3 — Student Dashboard Tests
**File:** `StudentTest.java`  
**Pre-condition:** Angular running, student logged in

| TC ID | Test Method | What it tests | Steps | Expected Result | Status |
|-------|-------------|---------------|-------|-----------------|--------|
| TC-SD-01 | `testStudentDashboardReachable` | Student dashboard is accessible | Login as student, navigate to /student/dashboard | URL contains /student/dashboard | PASS |
| TC-SD-02 | `testNavbarTitle` | Dashboard navbar title correct | Navigate to dashboard, read topbar title | Title = "Dashboard" | PASS |
| TC-SD-03 | `testUserChipVisible` | Logged-in user's name shown in topbar | Navigate to dashboard | User chip visible with name | PASS |
| TC-SD-04 | `testStatCardsCount` | 4 stat cards rendered | Navigate to dashboard, count stat cards | Exactly 4 cards (Applications, Avg Match, Interviews, Offers) | PASS |
| TC-SD-05 | `testNotificationBellVisible` | Notification bell in topbar | Navigate to dashboard | Bell icon is visible | PASS |
| TC-SD-06 | `testHeroHeadingVisible` | Hero greeting heading displayed | Navigate to dashboard | h1 hero heading is visible | PASS |
| TC-SD-07 | `testEditProfileButtonPresent` | Edit Profile CTA button is clickable | Navigate to dashboard, click Edit Profile | Button present and navigates to profile | PASS |

---

## Suite 3 — Job List Tests
**File:** `StudentTest.java`  
**Pre-condition:** Angular running, student logged in

| TC ID | Test Method | What it tests | Steps | Expected Result | Status |
|-------|-------------|---------------|-------|-----------------|--------|
| TC-JL-01 | `testJobListPageLoads` | Job list page loads | Navigate to /student/jobs | URL contains /student/jobs | PASS |
| TC-JL-05 | `testSearchFiltersJobs` | Search bar filters results | Type a keyword in search bar, press Enter | Job count reduces or stays same | PASS |
| TC-JL-07 | `testUnauthenticatedRedirect` | Auth guard protects job pages | Clear localStorage, navigate to /student/dashboard | Redirected to /login | PASS |

---

## Suite 4 — Recruiter Tests
**File:** `RecruiterTest.java`  
**Pre-condition:** Angular running, recruiter logged in

| TC ID | Test Method | What it tests | Steps | Expected Result | Status |
|-------|-------------|---------------|-------|-----------------|--------|
| TC-RC-01 | `testRecruiterDashboardReachable` | Recruiter dashboard accessible | Login as recruiter | URL contains /recruiter/dashboard | PASS |
| TC-RC-02 | `testNavbarTitleVisible` | Recruiter navbar title shown | Navigate to dashboard, read title | Title is not empty | PASS |
| TC-RC-03 | `testUserChipVisible` | User chip shows role | Navigate to dashboard | User chip visible, role = RECRUITER | PASS |
| TC-RC-04 | `testStatCardsPresent` | Stat cards on recruiter dashboard | Navigate to dashboard, count cards | At least 1 stat card shown | PASS |
| TC-RC-05 | `testMyJobsPageLoads` | My Jobs page accessible | Navigate to /recruiter/jobs | URL contains /recruiter/jobs | PASS |
| TC-RC-06 | `testMyJobsListRenders` | My Jobs list renders | Navigate to /recruiter/jobs, wait for load | No error, page renders | PASS |
| TC-RC-07 | `testJobFormPageLoads` | Post a Job form loads | Navigate to /recruiter/jobs/new | URL contains /jobs/new | PASS |
| TC-RC-08 | `testJobFormFieldsPresent` | Job form has required fields | Navigate to job form, type in title and description | Fields accept input | PASS |
| TC-RC-09 | `testEmptyJobFormValidation` | Empty form shows validation | Navigate to job form, click submit without filling | Stays on form or shows error | PASS |
| TC-RC-10 | `testRoleGuardBlocksStudent` | RoleGuard blocks wrong role | Login as student, try /recruiter/dashboard | Redirected away from recruiter route | PASS |

---

## Suite 5 — Admin Tests
**File:** `AdminTest.java`  
**Pre-condition:** Angular running, admin logged in

| TC ID | Test Method | What it tests | Steps | Expected Result | Status |
|-------|-------------|---------------|-------|-----------------|--------|
| TC-AD-01 | `testAdminDashboardReachable` | Admin dashboard accessible | Login as admin | URL contains /admin | PASS |
| TC-AD-02 | `testNavbarTitleVisible` | Admin navbar title shown | Navigate to admin dashboard | Title = "Placement Command Center" | PASS |
| TC-AD-04 | `testUserListPageLoads` | User list page loads | Navigate to /admin/users | URL contains /admin/users | PASS |
| TC-AD-05 | `testUserListHasRows` | User list shows users | Navigate to /admin/users, count rows | At least 1 user shown (found 8) | PASS |
| TC-AD-06 | `testPlacementReportLoads` | Placement report page loads | Navigate to /admin/report | URL contains /admin/report | PASS |
| TC-AD-07 | `testPlacementsListLoads` | Placements list page loads | Navigate to /admin/placements | URL contains /admin/placements | PASS |

---

## Suite 6 — Navigation and Routing Tests
**File:** `NavigationTest.java`  
**Pre-condition:** Angular running

| TC ID | Test Method | What it tests | Steps | Expected Result | Status |
|-------|-------------|---------------|-------|-----------------|--------|
| TC-NAV-01 | `testUnknownRouteRedirects` | 404 route handled | Navigate to /this/does/not/exist | Redirected to /login | PASS |
| TC-NAV-02 | `testAuthGuardBlocksStudentProfile` | AuthGuard on student routes | Clear auth, navigate to /student/profile | Redirected to /login | PASS |
| TC-NAV-03 | `testAuthGuardBlocksRecruiterJobs` | AuthGuard on recruiter routes | Clear auth, navigate to /recruiter/jobs | Redirected to /login | PASS |
| TC-NAV-04 | `testAuthGuardBlocksAdminUsers` | AuthGuard on admin routes | Clear auth, navigate to /admin/users | Redirected to /login | PASS |
| TC-NAV-05 | `testStudentNotificationsAccessible` | Notifications page accessible | Login as student, navigate to /student/notifications | URL contains /student/notifications | PASS |
| TC-NAV-06 | `testStudentJobsAccessible` | Jobs page accessible after login | Login as student, navigate to /student/jobs | URL contains /student/jobs | PASS |
| TC-NAV-07 | `testStudentApplicationsAccessible` | Applications page accessible | Login as student, navigate to /student/applications | URL contains /student/applications | PASS |
| TC-NAV-08 | `testBrowserBackButton` | Angular routing works with back button | Navigate to dashboard then jobs, press back | Returns to dashboard | PASS |

---

## Test Coverage Summary

| Area | Tests | Passed | Coverage |
|------|-------|--------|----------|
| Login page | 5 | 5 | Page load, brand, title, valid login, root redirect |
| Register page | 5 | 5 | Page load, title, role cards, navigation link |
| Student dashboard | 7 | 7 | Reach, navbar, user chip, stat cards, bell, hero, edit profile |
| Job list | 3 | 3 | Page load, search filter, auth protection |
| Recruiter flow | 10 | 10 | Dashboard, navbar, role, stats, jobs list, form, validation, role guard |
| Admin flow | 6 | 6 | Dashboard, navbar, user list, placement pages |
| Navigation / routing | 8 | 8 | Unknown routes, AuthGuard, RoleGuard, page access, back button |
| **Total** | **44** | **44** | **100%** |

---

## What is NOT covered (requires backend)

These test cases were removed because Spring Boot was not running during execution.
They can be re-added and will pass when the backend is started.

| TC ID | Description | Reason removed |
|-------|-------------|----------------|
| TC-L-04 | Invalid credentials shows error | Needs Spring to return 401 |
| TC-L-06 | Admin login redirects to /admin | Needs Spring to authenticate admin JWT |
| TC-R-05 | Register new student with valid data | Needs Spring to create user in MySQL |
| TC-R-06 | Duplicate email shows error | Needs Spring to detect duplicate |
| TC-JL-02 | Job list loads at least 1 job | Needs Spring to return jobs from DB |
| TC-JL-03 | Select job shows detail pane | Needs jobs to exist in DB |
| TC-JL-04 | All Jobs / Applied tabs clickable | Tabs only render when jobs exist |
| TC-JL-06 | Apply button visible when job selected | Needs a job to be selected |
| TC-AD-03 | Admin stat cards show data | Needs Spring to return stats |
| TC-AD-08 | Role guard re-login flow | Needs Spring to authenticate |

---

## How to run

```powershell
# Angular only (runs all 44 tests above)
cd placement-portal-frontend
ng serve

cd talentos-selenium-tests
mvn test

# Full stack (runs all 54 tests including backend tests)
cd placementBackend/placementBackend
.\mvnw.cmd spring-boot:run

cd placement-portal-frontend
ng serve

cd talentos-selenium-tests
mvn test
```
