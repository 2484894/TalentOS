package com.talentos.selenium.pages;

import com.talentos.selenium.utils.WaitHelper;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.util.List;

/**
 * AdminPages — covers admin-dashboard, user-list, placement-report.
 */
public class AdminPages {

    public static class DashboardPage {
        private final WebDriver driver;
        private final WaitHelper wait;

        private final By navbarTitle  = By.cssSelector("header.topbar h5");
        private final By statCards    = By.cssSelector(".stat-card");
        private final By loader       = By.cssSelector("app-loader");

        public DashboardPage(WebDriver driver) {
            this.driver = driver;
            this.wait   = new WaitHelper(driver);
        }

        public void open(String baseUrl) {
            driver.get(baseUrl + "/admin/dashboard");
        }

        public void waitForLoad() { wait.gone(loader); }

        public String getNavbarTitle() {
            return wait.visible(navbarTitle).getText();
        }

        public int getStatCardCount() {
            return driver.findElements(statCards).size();
        }

        public boolean isOnAdminDashboard() {
            return driver.getCurrentUrl().contains("/admin");
        }
    }

    public static class UserListPage {
        private final WebDriver driver;
        private final WaitHelper wait;

        private final By userRows  = By.cssSelector("tr.user-row, .user-item, tbody tr");
        private final By loader    = By.cssSelector("app-loader");
        private final By pageTitle = By.cssSelector("header.topbar h5");

        public UserListPage(WebDriver driver) {
            this.driver = driver;
            this.wait   = new WaitHelper(driver);
        }

        public void open(String baseUrl) {
            driver.get(baseUrl + "/admin/users");
        }

        public void waitForLoad() { wait.gone(loader); }

        public int getUserCount() {
            return driver.findElements(userRows).size();
        }

        public String getPageTitle() {
            return wait.visible(pageTitle).getText();
        }
    }

    public static class PlacementReportPage {
        private final WebDriver driver;
        private final WaitHelper wait;

        private final By loader    = By.cssSelector("app-loader");
        private final By pageTitle = By.cssSelector("header.topbar h5");
        private final By reportRows = By.cssSelector("tr, .placement-row");

        public PlacementReportPage(WebDriver driver) {
            this.driver = driver;
            this.wait   = new WaitHelper(driver);
        }

        public void open(String baseUrl) {
            driver.get(baseUrl + "/admin/report");
        }

        public void waitForLoad() { wait.gone(loader); }

        public boolean isLoaded() {
            return driver.getCurrentUrl().contains("/admin/report");
        }
    }
}
