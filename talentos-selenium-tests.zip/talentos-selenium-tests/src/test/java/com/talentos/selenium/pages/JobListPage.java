package com.talentos.selenium.pages;

import com.talentos.selenium.utils.WaitHelper;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

/**
 * JobListPage — matches job-list.component.html
 *
 * Two-pane layout:
 *   Left pane  (.jobs-list-pane)  — list of job cards + search/filter bar
 *   Right pane (.jobs-detail-pane) — selected job details + Apply button
 */
public class JobListPage {

    private final WebDriver driver;
    private final WaitHelper wait;

    private final By searchInput   = By.cssSelector(".filter-search input");
    private final By jobTypeSelect = By.cssSelector("select.filter-select");
    private final By jobListItems  = By.cssSelector(".job-list-item");
    private final By allJobsTab    = By.xpath("//button[contains(@class,'list-tab') and text()='All Jobs']");
    private final By appliedTab    = By.xpath("//button[contains(@class,'list-tab') and text()='Applied Jobs']");
    private final By detailTitle   = By.cssSelector(".detail-title");
    private final By applyButton   = By.cssSelector("button.apply-button");
    private final By appliedBadge  = By.cssSelector(".applied-badge");
    private final By loader        = By.cssSelector("app-loader");
    private final By clearFilters  = By.xpath("//button[contains(text(),'Clear filters')]");
    private final By emptyState    = By.cssSelector(".empty-state");
    private final By successAlert  = By.cssSelector(".alert.alert-success");
    private final By errorAlert    = By.cssSelector(".alert.alert-danger");

    public JobListPage(WebDriver driver) {
        this.driver = driver;
        this.wait   = new WaitHelper(driver);
    }

    public void open(String baseUrl) {
        driver.get(baseUrl + "/student/jobs");
    }

    public void waitForLoad() {
        wait.gone(loader);
    }

    public int getJobCount() {
        return driver.findElements(jobListItems).size();
    }

    public void searchFor(String keyword) {
        WebElement input = wait.visible(searchInput);
        input.clear();
        input.sendKeys(keyword);
        input.sendKeys(org.openqa.selenium.Keys.ENTER);
    }

    public void filterByType(String type) {
        new org.openqa.selenium.support.ui.Select(
                wait.visible(jobTypeSelect)).selectByValue(type);
    }

    public void clickAllJobsTab() {
        wait.clickable(allJobsTab).click();
    }

    public void clickAppliedTab() {
        wait.clickable(appliedTab).click();
    }

    public void selectJobAtIndex(int index) {
        List<WebElement> items = driver.findElements(jobListItems);
        if (index < items.size()) items.get(index).click();
    }

    public String getSelectedJobTitle() {
        return wait.visible(detailTitle).getText();
    }

    public boolean isApplyButtonVisible() {
        return !driver.findElements(applyButton).isEmpty();
    }

    public void clickApply() {
        wait.clickable(applyButton).click();
    }

    public boolean isAppliedBadgeVisible() {
        return !driver.findElements(appliedBadge).isEmpty();
    }

    public boolean isEmptyStateVisible() {
        return !driver.findElements(emptyState).isEmpty();
    }

    public String getSuccessMessage() {
        return wait.visible(successAlert).getText();
    }

    public void clearFiltersIfVisible() {
        if (!driver.findElements(clearFilters).isEmpty())
            driver.findElements(clearFilters).get(0).click();
    }
}
