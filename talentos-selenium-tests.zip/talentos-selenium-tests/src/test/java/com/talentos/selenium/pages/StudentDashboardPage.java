package com.talentos.selenium.pages;

import com.talentos.selenium.utils.WaitHelper;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

/**
 * StudentDashboardPage — matches student-dashboard.component.html
 *
 * Key elements:
 *   - .display-hero           : hero heading (greeting + user name)
 *   - .stat-card              : stat cards (Applications, Avg Match, Interviews, Offers)
 *   - .job-card-student       : AI-matched job cards
 *   - .app-list-item          : recent application list items
 *   - app-loader              : spinner while data loads
 *   - .btn-profile-cta        : "Complete Profile" button on the profile card
 */
public class StudentDashboardPage {

    private final WebDriver driver;
    private final WaitHelper wait;

    private final By heroHeading    = By.cssSelector("h1.display-hero");
    private final By statCards      = By.cssSelector(".stat-card");
    private final By jobCards       = By.cssSelector(".job-card-student");
    private final By appItems       = By.cssSelector(".app-list-item");
    private final By loader         = By.cssSelector("app-loader");
    private final By profileCta     = By.cssSelector(".btn-profile-cta");
    private final By editProfileBtn = By.cssSelector("a.btn.btn-primary.btn-lg[routerlink='/student/profile']");
    private final By browseJobsBtn  = By.cssSelector("button.btn.btn-soft.btn-sm");
    private final By navbarTitle    = By.cssSelector("header.topbar h5");

    public StudentDashboardPage(WebDriver driver) {
        this.driver = driver;
        this.wait   = new WaitHelper(driver);
    }

    public void open(String baseUrl) {
        driver.get(baseUrl + "/student/dashboard");
    }

    /** Wait for the loader to disappear (Angular API call finishes). */
    public void waitForLoad() {
        wait.gone(loader);
    }

    public String getNavbarTitle() {
        return wait.visible(navbarTitle).getText();
    }

    public boolean isHeroVisible() {
        return wait.visible(heroHeading).isDisplayed();
    }

    public int getStatCardCount() {
        List<WebElement> cards = driver.findElements(statCards);
        return cards.size();
    }

    public int getJobCardCount() {
        List<WebElement> cards = driver.findElements(jobCards);
        return cards.size();
    }

    public int getApplicationCount() {
        List<WebElement> items = driver.findElements(appItems);
        return items.size();
    }

    public void clickFirstJobCard() {
        List<WebElement> cards = driver.findElements(jobCards);
        if (!cards.isEmpty()) cards.get(0).click();
    }

    public void clickCompleteProfile() {
        wait.clickable(profileCta).click();
    }

    public void clickEditProfile() {
        wait.clickable(editProfileBtn).click();
    }
}
