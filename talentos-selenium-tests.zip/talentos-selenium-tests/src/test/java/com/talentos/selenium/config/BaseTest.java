package com.talentos.selenium.config;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import java.time.Duration;
import java.util.logging.Logger;

/**
 * BaseTest — shared driver lifecycle for all test classes.
 *
 * HOW TO POINT AT YOUR RUNNING APP:
 *   Change BASE_URL below to match where your Angular app is running.
 *   Examples:
 *     "http://localhost:4200"  — ng serve (Angular dev server)
 *     "http://localhost:8080"  — Spring Boot serving the Angular build
 */
public class BaseTest {

    protected static WebDriver driver;
    protected static WebDriverWait wait;
    protected static final Logger log = Logger.getLogger("TalentOS-E2E");

    // ← Change this to your running app URL
    protected static final String BASE_URL = "http://localhost:4200";

    // Credentials that match your seeded/test data
    protected static final String STUDENT_EMAIL    = "student@gmail.com";
    protected static final String STUDENT_PASSWORD = "password123";
    protected static final String RECRUITER_EMAIL    = "recruiter@test.com";
    protected static final String RECRUITER_PASSWORD = "password123";
    protected static final String ADMIN_EMAIL    = "admin@portal.com";
    protected static final String ADMIN_PASSWORD = "admin123";

    @BeforeClass
    public void setUp() {
        log.info("=== Setting up ChromeDriver via WebDriverManager ===");
        WebDriverManager.chromedriver().browserVersion("148").setup();

        ChromeOptions options = new ChromeOptions();
        // Uncomment the next line to run headless (no browser window — useful for CI):
        // options.addArguments("--headless=new");
        options.addArguments("--start-maximized");
        options.addArguments("--disable-notifications");

        driver = new ChromeDriver(options);
        wait   = new WebDriverWait(driver, Duration.ofSeconds(15));

        log.info("Browser opened. Base URL: " + BASE_URL);
        driver.get(BASE_URL);
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) {
            log.info("=== Closing browser ===");
            driver.quit();
        }
    }
}
