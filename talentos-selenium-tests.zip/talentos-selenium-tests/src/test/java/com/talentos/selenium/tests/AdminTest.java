package com.talentos.selenium.tests;

import com.talentos.selenium.config.BaseTest;
import com.talentos.selenium.pages.AdminPages;
import com.talentos.selenium.pages.LoginPage;
import com.talentos.selenium.pages.NavbarPage;
import com.talentos.selenium.utils.TestLogger;
import com.talentos.selenium.utils.WaitHelper;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * AdminTest — covers admin dashboard, user list, placement report pages.
 *
 * Test cases:
 *   TC-AD-01  Admin login redirects to /admin/dashboard
 *   TC-AD-02  Admin dashboard navbar title visible
 *   TC-AD-03  Admin dashboard stat cards present
 *   TC-AD-04  User list page loads at /admin/users
 *   TC-AD-05  User list renders rows (at least 1 user exists)
 *   TC-AD-06  Placement report page loads at /admin/report
 *   TC-AD-07  Placements list page loads at /admin/placements
 *   TC-AD-08  Admin role guard blocks student from /admin routes
 */
public class AdminTest extends BaseTest {

    private LoginPage loginPage;
    private NavbarPage navbarPage;
    private AdminPages.DashboardPage dashboardPage;
    private AdminPages.UserListPage userListPage;
    private AdminPages.PlacementReportPage reportPage;

    @BeforeClass
    public void loginAsAdmin() {
        TestLogger.separator("ADMIN TESTS");
        loginPage     = new LoginPage(driver);
        navbarPage    = new NavbarPage(driver);
        dashboardPage = new AdminPages.DashboardPage(driver);
        userListPage  = new AdminPages.UserListPage(driver);
        reportPage    = new AdminPages.PlacementReportPage(driver);

        loginPage.open(BASE_URL);
        loginPage.loginAs(ADMIN_EMAIL, ADMIN_PASSWORD);
        WaitHelper.sleep(3000);
    }

    @Test(priority = 1, description = "TC-AD-01: Admin lands on /admin after login")
    public void testAdminDashboardReachable() {
        try {
            Assert.assertTrue(dashboardPage.isOnAdminDashboard(),
                    "Admin should land on /admin. URL: " + driver.getCurrentUrl());
            TestLogger.pass("TC-AD-01: Admin dashboard reachable");
        } catch (AssertionError | Exception e) {
            TestLogger.fail("TC-AD-01", e.getMessage());
            throw e;
        }
    }

    @Test(priority = 2, description = "TC-AD-02: Admin dashboard navbar title visible")
    public void testNavbarTitleVisible() {
        try {
            dashboardPage.open(BASE_URL);
            dashboardPage.waitForLoad();
            String title = dashboardPage.getNavbarTitle();
            Assert.assertFalse(title.isEmpty(),
                    "Navbar title should not be empty");
            TestLogger.pass("TC-AD-02: Admin navbar title: " + title);
        } catch (AssertionError | Exception e) {
            TestLogger.fail("TC-AD-02", e.getMessage());
            throw e;
        }
    }



    @Test(priority = 4, description = "TC-AD-04: User list page loads at /admin/users")
    public void testUserListPageLoads() {
        try {
            userListPage.open(BASE_URL);
            Assert.assertTrue(driver.getCurrentUrl().contains("/admin/users"),
                    "Should be on /admin/users");
            TestLogger.pass("TC-AD-04: User list page loads");
        } catch (AssertionError | Exception e) {
            TestLogger.fail("TC-AD-04", e.getMessage());
            throw e;
        }
    }

    @Test(priority = 5, description = "TC-AD-05: User list renders at least 1 user")
    public void testUserListHasRows() {
        try {
            userListPage.open(BASE_URL);
            userListPage.waitForLoad();
            int count = userListPage.getUserCount();
            Assert.assertTrue(count > 0,
                    "User list should have at least 1 user. Count: " + count);
            TestLogger.pass("TC-AD-05: User list shows " + count + " user(s)");
        } catch (AssertionError | Exception e) {
            TestLogger.fail("TC-AD-05", e.getMessage());
            throw e;
        }
    }

    @Test(priority = 6, description = "TC-AD-06: Placement report page loads at /admin/report")
    public void testPlacementReportLoads() {
        try {
            reportPage.open(BASE_URL);
            reportPage.waitForLoad();
            Assert.assertTrue(reportPage.isLoaded(),
                    "Should be on /admin/report");
            TestLogger.pass("TC-AD-06: Placement report page loads");
        } catch (AssertionError | Exception e) {
            TestLogger.fail("TC-AD-06", e.getMessage());
            throw e;
        }
    }

    @Test(priority = 7, description = "TC-AD-07: Placements list page loads at /admin/placements")
    public void testPlacementsListLoads() {
        try {
            driver.get(BASE_URL + "/admin/placements");
            WaitHelper.sleep(2000);
            Assert.assertTrue(driver.getCurrentUrl().contains("/admin/placements"),
                    "Should be on /admin/placements");
            TestLogger.pass("TC-AD-07: Placements list page loads");
        } catch (AssertionError | Exception e) {
            TestLogger.fail("TC-AD-07", e.getMessage());
            throw e;
        }
    }
}
