package com.talentos.selenium.tests;

import com.talentos.selenium.config.BaseTest;
import com.talentos.selenium.pages.LoginPage;
import com.talentos.selenium.pages.NavbarPage;
import com.talentos.selenium.pages.StudentDashboardPage;
import com.talentos.selenium.pages.JobListPage;
import com.talentos.selenium.utils.TestLogger;
import com.talentos.selenium.utils.WaitHelper;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * StudentTest — covers student-dashboard and job-list pages.
 *
 * Dashboard test cases:
 *   TC-SD-01  Student can log in and reach /student/dashboard
 *   TC-SD-02  Navbar title is "Dashboard"
 *   TC-SD-03  User chip (name + role) is visible in topbar
 *   TC-SD-04  Exactly 4 stat cards are rendered (Applications, Avg Match, Interviews, Offers)
 *   TC-SD-05  Notification bell is visible in topbar
 *   TC-SD-06  Hero heading is displayed
 *   TC-SD-07  "Edit Profile" button is present
 *
 * Job list test cases:
 *   TC-JL-01  Student can navigate to /student/jobs
 *   TC-JL-02  Job list renders at least one item after load
 *   TC-JL-03  Selecting a job from the list shows its title in the detail pane
 *   TC-JL-04  "All Jobs" and "Applied Jobs" tabs are clickable
 *   TC-JL-05  Search by keyword filters the job list
 *   TC-JL-06  Filter by job type (FULLTIME) filters results
 *   TC-JL-07  Apply button is visible when a job is selected
 *   TC-JL-08  Unauthenticated access to /student/dashboard redirects to /login
 */
public class StudentTest extends BaseTest {

    private LoginPage loginPage;
    private StudentDashboardPage dashboardPage;
    private JobListPage jobListPage;
    private NavbarPage navbarPage;

    @BeforeClass
    public void loginAsStudent() {
        TestLogger.separator("STUDENT TESTS");
        loginPage     = new LoginPage(driver);
        dashboardPage = new StudentDashboardPage(driver);
        jobListPage   = new JobListPage(driver);
        navbarPage    = new NavbarPage(driver);

        // Login once for the whole class
        loginPage.open(BASE_URL);
        loginPage.loginAs(STUDENT_EMAIL, STUDENT_PASSWORD);
        WaitHelper.sleep(3000);
    }

    // ─── Dashboard Tests ────────────────────────────────────────────────────

    @Test(priority = 1, description = "TC-SD-01: Student dashboard is reachable")
    public void testStudentDashboardReachable() {
        try {
            dashboardPage.open(BASE_URL);
            Assert.assertTrue(driver.getCurrentUrl().contains("/student/dashboard"),
                    "Should be on /student/dashboard");
            TestLogger.pass("TC-SD-01: Student dashboard reachable");
        } catch (AssertionError | Exception e) {
            TestLogger.fail("TC-SD-01", e.getMessage());
            throw e;
        }
    }

    @Test(priority = 2, description = "TC-SD-02: Navbar title is 'Dashboard'")
    public void testNavbarTitle() {
        try {
            dashboardPage.open(BASE_URL);
            String title = dashboardPage.getNavbarTitle();
            Assert.assertEquals(title, "Dashboard",
                    "Navbar title should be 'Dashboard'");
            TestLogger.pass("TC-SD-02: Navbar title is 'Dashboard'");
        } catch (AssertionError | Exception e) {
            TestLogger.fail("TC-SD-02", e.getMessage());
            throw e;
        }
    }

    @Test(priority = 3, description = "TC-SD-03: User chip is visible in topbar")
    public void testUserChipVisible() {
        try {
            dashboardPage.open(BASE_URL);
            Assert.assertTrue(navbarPage.isUserChipVisible(),
                    "User chip should be visible after login");
            TestLogger.pass("TC-SD-03: User chip visible — " + navbarPage.getUserName());
        } catch (AssertionError | Exception e) {
            TestLogger.fail("TC-SD-03", e.getMessage());
            throw e;
        }
    }

    @Test(priority = 4, description = "TC-SD-04: 4 stat cards are rendered")
    public void testStatCardsCount() {
        try {
            dashboardPage.open(BASE_URL);
            dashboardPage.waitForLoad();
            int count = dashboardPage.getStatCardCount();
            Assert.assertEquals(count, 4,
                    "Should have exactly 4 stat cards");
            TestLogger.pass("TC-SD-04: 4 stat cards rendered");
        } catch (AssertionError | Exception e) {
            TestLogger.fail("TC-SD-04", e.getMessage());
            throw e;
        }
    }

    @Test(priority = 5, description = "TC-SD-05: Notification bell is visible")
    public void testNotificationBellVisible() {
        try {
            dashboardPage.open(BASE_URL);
            Assert.assertTrue(navbarPage.isNotificationBellVisible(),
                    "Notification bell should be visible");
            TestLogger.pass("TC-SD-05: Notification bell visible");
        } catch (AssertionError | Exception e) {
            TestLogger.fail("TC-SD-05", e.getMessage());
            throw e;
        }
    }

    @Test(priority = 6, description = "TC-SD-06: Hero heading is displayed")
    public void testHeroHeadingVisible() {
        try {
            dashboardPage.open(BASE_URL);
            Assert.assertTrue(dashboardPage.isHeroVisible(),
                    "Hero heading should be visible");
            TestLogger.pass("TC-SD-06: Hero heading visible");
        } catch (AssertionError | Exception e) {
            TestLogger.fail("TC-SD-06", e.getMessage());
            throw e;
        }
    }

    @Test(priority = 7, description = "TC-SD-07: Edit Profile CTA button present")
    public void testEditProfileButtonPresent() {
        try {
            dashboardPage.open(BASE_URL);
            dashboardPage.waitForLoad();
            dashboardPage.clickEditProfile();
            WaitHelper.sleep(1000);
            // Navigate back
            dashboardPage.open(BASE_URL);
            TestLogger.pass("TC-SD-07: Edit Profile button present and clickable");
        } catch (AssertionError | Exception e) {
            TestLogger.fail("TC-SD-07", e.getMessage());
            throw e;
        }
    }

    // ─── Job List Tests ─────────────────────────────────────────────────────

    @Test(priority = 8, description = "TC-JL-01: Student can navigate to /student/jobs")
    public void testJobListPageLoads() {
        try {
            jobListPage.open(BASE_URL);
            Assert.assertTrue(driver.getCurrentUrl().contains("/student/jobs"),
                    "Should be on /student/jobs");
            TestLogger.pass("TC-JL-01: Job list page loads");
        } catch (AssertionError | Exception e) {
            TestLogger.fail("TC-JL-01", e.getMessage());
            throw e;
        }
    }







    @Test(priority = 12, description = "TC-JL-05: Search filters the job list")
    public void testSearchFiltersJobs() {
        try {
            jobListPage.open(BASE_URL);
            jobListPage.waitForLoad();
            int beforeSearch = jobListPage.getJobCount();
            jobListPage.searchFor("xyznotajobtitle12345");
            WaitHelper.sleep(1500);
            // Either empty state or fewer results
            int afterSearch = jobListPage.getJobCount();
            Assert.assertTrue(afterSearch <= beforeSearch,
                    "Search should reduce or maintain job count");
            TestLogger.pass("TC-JL-05: Search filters jobs. Before=" + beforeSearch + " After=" + afterSearch);
            // Clear
            jobListPage.clearFiltersIfVisible();
        } catch (AssertionError | Exception e) {
            TestLogger.fail("TC-JL-05", e.getMessage());
            throw e;
        }
    }
    @Test(priority = 14, description = "TC-JL-07: Unauthenticated access redirects to /login")
    public void testUnauthenticatedRedirect() {
        try {
            // Clear session storage to simulate logout
            ((org.openqa.selenium.JavascriptExecutor) driver)
                    .executeScript("localStorage.clear(); sessionStorage.clear();");
            driver.get(BASE_URL + "/student/dashboard");
            WaitHelper.sleep(2000);
            Assert.assertTrue(driver.getCurrentUrl().contains("/login"),
                    "Unauthenticated access should redirect to /login");
            TestLogger.pass("TC-JL-07: Unauthenticated redirect to /login works");
            // Re-login for subsequent tests
            loginPage.loginAs(STUDENT_EMAIL, STUDENT_PASSWORD);
            WaitHelper.sleep(3000);
        } catch (AssertionError | Exception e) {
            TestLogger.fail("TC-JL-07", e.getMessage());
            throw e;
        }
    }
}
