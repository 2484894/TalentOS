package com.talentos.selenium.tests;

import com.talentos.selenium.config.BaseTest;
import com.talentos.selenium.pages.LoginPage;
import com.talentos.selenium.utils.TestLogger;
import com.talentos.selenium.utils.WaitHelper;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * LoginTest — tests for login.component.html
 *
 * Test cases:
 *   TC-L-01  Login page loads at /login
 *   TC-L-02  Brand name "TalentOS" is displayed
 *   TC-L-03  Form title is "Sign in"
 *   TC-L-04  Login with empty fields shows validation (submit is disabled)
 *   TC-L-05  Login with invalid credentials shows error message
 *   TC-L-06  Student login redirects to /student/dashboard
 *   TC-L-07  Admin login redirects to /admin/dashboard
 *   TC-L-08  Register link navigates to /register
 *   TC-L-09  Root URL "/" redirects to /login
 */
public class LoginTest extends BaseTest {

    private LoginPage loginPage;

    @BeforeClass
    public void initPage() {
        TestLogger.separator("LOGIN TESTS");
        loginPage = new LoginPage(driver);
    }

    @Test(priority = 1, description = "TC-L-01: Login page loads at /login")
    public void testLoginPageLoads() {
        try {
            loginPage.open(BASE_URL);
            Assert.assertTrue(loginPage.isOnLoginPage(),
                    "URL should contain /login");
            TestLogger.pass("TC-L-01: Login page loads at /login");
        } catch (AssertionError | Exception e) {
            TestLogger.fail("TC-L-01", e.getMessage());
            throw e;
        }
    }

    @Test(priority = 2, description = "TC-L-02: TalentOS brand name is visible on login page")
    public void testBrandNameVisible() {
        try {
            loginPage.open(BASE_URL);
            String brand = loginPage.getBrandName();
            Assert.assertEquals(brand, "TalentOS",
                    "Brand name should be TalentOS");
            TestLogger.pass("TC-L-02: Brand name 'TalentOS' visible");
        } catch (AssertionError | Exception e) {
            TestLogger.fail("TC-L-02", e.getMessage());
            throw e;
        }
    }

    @Test(priority = 3, description = "TC-L-03: Form title is 'Sign in'")
    public void testFormTitle() {
        try {
            loginPage.open(BASE_URL);
            String title = loginPage.getFormTitle();
            Assert.assertEquals(title, "Sign in",
                    "Form title should be 'Sign in'");
            TestLogger.pass("TC-L-03: Form title is 'Sign in'");
        } catch (AssertionError | Exception e) {
            TestLogger.fail("TC-L-03", e.getMessage());
            throw e;
        }
    }
    @Test(priority = 5, description = "TC-L-05: Student login redirects to student dashboard")
    public void testStudentLoginRedirectsToDashboard() {
        try {
            loginPage.open(BASE_URL);
            loginPage.loginAs(STUDENT_EMAIL, STUDENT_PASSWORD);
            WaitHelper.sleep(3000);
            String currentUrl = driver.getCurrentUrl();
            Assert.assertTrue(currentUrl.contains("/student/dashboard"),
                    "Student should be redirected to /student/dashboard. Actual URL: " + currentUrl);
            TestLogger.pass("TC-L-05: Student login → redirected to " + currentUrl);
        } catch (AssertionError | Exception e) {
            TestLogger.fail("TC-L-05", e.getMessage());
            throw e;
        }
    }



    @Test(priority = 8, description = "TC-L-08: Root URL '/' redirects to /login")
    public void testRootRedirectsToLogin() {
        try {
            ((org.openqa.selenium.JavascriptExecutor) driver)
                    .executeScript("localStorage.clear(); sessionStorage.clear();");
            driver.get(BASE_URL + "/");
            WaitHelper.sleep(2000);
            Assert.assertTrue(driver.getCurrentUrl().contains("/login"),
                    "Root URL should redirect to /login");
            TestLogger.pass("TC-L-08: Root URL redirects to /login");
        } catch (AssertionError | Exception e) {
            TestLogger.fail("TC-L-08", e.getMessage());
            throw e;
        }
    }
}
