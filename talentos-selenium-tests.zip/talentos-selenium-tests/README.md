# TalentOS Selenium E2E Tests

A **completely separate Maven project** that runs end-to-end Selenium tests
against the TalentOS Angular frontend running on localhost.

---

## Project structure

```
talentos-selenium-tests/
├── pom.xml                                        ← Maven dependencies
├── testng.xml                                     ← Test suite config
├── logs/
│   └── test-results.log                           ← Auto-generated log file
└── src/test/java/com/talentos/selenium/
    ├── config/
    │   └── BaseTest.java                          ← Driver setup, BASE_URL, credentials
    ├── pages/                                     ← Page Object Model classes
    │   ├── LoginPage.java
    │   ├── RegisterPage.java
    │   ├── StudentDashboardPage.java
    │   ├── JobListPage.java
    │   ├── NavbarPage.java
    │   ├── RecruiterPages.java                    ← Dashboard + JobForm + MyJobs
    │   └── AdminPages.java                        ← Dashboard + UserList + Report
    ├── tests/                                     ← TestNG test classes
    │   ├── LoginTest.java         (8 test cases)
    │   ├── RegisterTest.java      (7 test cases)
    │   ├── StudentTest.java      (14 test cases)
    │   ├── RecruiterTest.java    (10 test cases)
    │   ├── AdminTest.java         (8 test cases)
    │   └── NavigationTest.java    (8 test cases)
    └── utils/
        ├── TestLogger.java                        ← Writes PASS/FAIL to logs/
        └── WaitHelper.java                        ← Angular-safe wait helpers
```

---

## Prerequisites

| Tool | Version |
|------|---------|
| Java | 11 or 17 |
| Maven | 3.6+ |
| Google Chrome | Any recent version |
| ChromeDriver | **Auto-downloaded** by WebDriverManager |

> You do **not** need to manually download ChromeDriver.
> WebDriverManager detects your Chrome version and downloads the matching driver.

---

## Step 1 — Start TalentOS Angular app

In your `placement-portal-frontend` directory:

```bash
npm install          # first time only
ng serve             # starts on http://localhost:4200
```

Verify it works by opening `http://localhost:4200` in your browser.

> If your app runs on a different port, update `BASE_URL` in `BaseTest.java`.

---

## Step 2 — Configure test credentials

Open `src/test/java/com/talentos/selenium/config/BaseTest.java` and update
these constants to match real users in your database:

```java
protected static final String STUDENT_EMAIL    = "student@test.com";
protected static final String STUDENT_PASSWORD = "password123";

protected static final String RECRUITER_EMAIL    = "recruiter@test.com";
protected static final String RECRUITER_PASSWORD = "password123";

protected static final String ADMIN_EMAIL    = "admin@talentos.com";
protected static final String ADMIN_PASSWORD = "admin123";
```

The admin user is seeded automatically by `AdminSeeder.java` in the Spring backend.
For student and recruiter, register them via the app or use existing accounts.

---

## Step 3 — Run the tests

Open a **separate terminal** in this project folder:

```bash
# Run all 55 test cases
mvn test

# Run only login tests
mvn test -Dtest=LoginTest

# Run only student tests
mvn test -Dtest=StudentTest

# Run without opening a browser window (headless)
# Uncomment the --headless line in BaseTest.java first, then:
mvn test
```

---

## Step 4 — View results

### Terminal output
TestNG prints PASS/FAIL for every test in the terminal.

### Log file
Every test result is written to:
```
logs/test-results.log
```

Example log output:
```
======================================================================
  SUITE: LOGIN TESTS
  Started: 2025-06-01 10:30:00
======================================================================
[2025-06-01 10:30:01] [PASS] TC-L-01: Login page loads at /login
[2025-06-01 10:30:03] [PASS] TC-L-02: Brand name 'TalentOS' visible
[2025-06-01 10:30:05] [PASS] TC-L-03: Form title is 'Sign in'
[2025-06-01 10:30:08] [PASS] TC-L-04: Invalid login shows error: Invalid credentials
[2025-06-01 10:30:11] [PASS] TC-L-05: Student login → redirected to http://localhost:4200/student/dashboard
[2025-06-01 10:30:14] [FAIL] TC-L-06: Admin login → redirected to /admin — Expected condition failed
```

### TestNG HTML report
After `mvn test`, open:
```
target/surefire-reports/index.html
```

---

## All test cases (55 total)

### Login (8)
| ID | Description |
|----|-------------|
| TC-L-01 | Login page loads at /login |
| TC-L-02 | TalentOS brand name is visible |
| TC-L-03 | Form title is "Sign in" |
| TC-L-04 | Invalid credentials shows error alert |
| TC-L-05 | Student login redirects to /student/dashboard |
| TC-L-06 | Admin login redirects to /admin/dashboard |
| TC-L-07 | Register link navigates to /register |
| TC-L-08 | Root URL "/" redirects to /login |

### Register (7)
| ID | Description |
|----|-------------|
| TC-R-01 | Register page loads at /register |
| TC-R-02 | Form title is "Create account" |
| TC-R-03 | Student role card is selectable |
| TC-R-04 | Recruiter role card is selectable |
| TC-R-05 | Register new student with valid data succeeds |
| TC-R-06 | Duplicate email shows error |
| TC-R-07 | Sign-in link navigates to /login |

### Student Dashboard + Jobs (14)
| ID | Description |
|----|-------------|
| TC-SD-01 | Student dashboard is reachable |
| TC-SD-02 | Navbar title is "Dashboard" |
| TC-SD-03 | User chip is visible in topbar |
| TC-SD-04 | Exactly 4 stat cards rendered |
| TC-SD-05 | Notification bell is visible |
| TC-SD-06 | Hero heading is displayed |
| TC-SD-07 | Edit Profile CTA button present |
| TC-JL-01 | Student can navigate to /student/jobs |
| TC-JL-02 | Job list renders at least one item |
| TC-JL-03 | Selecting a job shows detail pane |
| TC-JL-04 | All Jobs and Applied Jobs tabs clickable |
| TC-JL-05 | Search filters the job list |
| TC-JL-06 | Apply button visible when job selected |
| TC-JL-07 | Unauthenticated access redirects to /login |

### Recruiter (10)
| ID | Description |
|----|-------------|
| TC-RC-01 | Recruiter lands on /recruiter/dashboard |
| TC-RC-02 | Recruiter dashboard navbar title visible |
| TC-RC-03 | User chip visible and shows role |
| TC-RC-04 | Stat cards present on recruiter dashboard |
| TC-RC-05 | Recruiter can navigate to /recruiter/jobs |
| TC-RC-06 | My Jobs list renders without errors |
| TC-RC-07 | Post a Job page loads at /recruiter/jobs/new |
| TC-RC-08 | Job form has required fields |
| TC-RC-09 | Submitting empty form stays on form (validation) |
| TC-RC-10 | Role guard blocks student from /recruiter routes |

### Admin (8)
| ID | Description |
|----|-------------|
| TC-AD-01 | Admin lands on /admin after login |
| TC-AD-02 | Admin dashboard navbar title visible |
| TC-AD-03 | Admin dashboard stat cards present |
| TC-AD-04 | User list page loads at /admin/users |
| TC-AD-05 | User list renders at least 1 user |
| TC-AD-06 | Placement report page loads at /admin/report |
| TC-AD-07 | Placements list page loads at /admin/placements |
| TC-AD-08 | Role guard blocks student from /admin routes |

### Navigation / Routing (8)
| ID | Description |
|----|-------------|
| TC-NAV-01 | Unknown route redirects to /login |
| TC-NAV-02 | AuthGuard blocks /student/profile when unauthenticated |
| TC-NAV-03 | AuthGuard blocks /recruiter/jobs when unauthenticated |
| TC-NAV-04 | AuthGuard blocks /admin/users when unauthenticated |
| TC-NAV-05 | /student/notifications accessible after login |
| TC-NAV-06 | /student/jobs accessible after login |
| TC-NAV-07 | /student/applications accessible after login |
| TC-NAV-08 | Browser back button works after Angular navigation |

---

## Changing the URL

All tests inherit from `BaseTest.java`. To point at a different URL, change
one line:

```java
// Development (ng serve):
protected static final String BASE_URL = "http://localhost:4200";

// Spring Boot serving Angular build:
protected static final String BASE_URL = "http://localhost:8080";

// Deployed / staging:
protected static final String BASE_URL = "https://talentos.yoursite.com";
```

---

## Running headless (no browser window)

Useful for CI/CD pipelines. In `BaseTest.java`, uncomment:

```java
options.addArguments("--headless=new");
```

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| `Connection refused` | Angular is not running. Run `ng serve` first. |
| `NoSuchElementException` | The locator doesn't match. Inspect the element in Chrome DevTools and update the `By` in the Page Object. |
| `SessionNotCreatedException` | Chrome updated. WebDriverManager handles this — make sure you have internet access on first run. |
| Tests pass locally but fail on CI | Add `--headless=new`, `--no-sandbox`, `--disable-dev-shm-usage` to Chrome options. |
| `Element not interactable` | Angular hasn't rendered yet. The `WaitHelper` should handle this — increase timeout in `WaitHelper.java` if needed. |
