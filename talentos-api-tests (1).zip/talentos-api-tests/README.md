# TalentOS API Test Suite

REST Assured + TestNG automated API test suite with Extent Reports for the **TalentOS Placement Portal**.

---

## 📁 Project Structure

```
talentos-api-tests/
├── pom.xml
└── src/test/
    ├── java/com/talentos/
    │   ├── base/
    │   │   └── BaseTest.java            # RestAssured setup, helper methods
    │   ├── constants/
    │   │   └── ApiConstants.java        # All API endpoint paths + HTTP codes
    │   ├── utils/
    │   │   ├── ConfigManager.java       # Reads config.properties
    │   │   ├── TestContext.java         # Shared tokens & IDs across tests
    │   │   ├── ExtentReportManager.java # Extent Reports singleton
    │   │   ├── ExtentReportListener.java# TestNG ITestListener for report
    │   │   └── TestInfo.java            # Custom annotation
    │   └── tests/
    │       ├── AuthTest.java            # 20 tests — register + login
    │       ├── StudentProfileTest.java  # 14 tests — get + update profile
    │       ├── ResumeTest.java          #  5 tests — PDF upload
    │       ├── JobListingTest.java      # 31 tests — CRUD + AI + browse
    │       ├── ApplicationTest.java     # 27 tests — apply + manage
    │       ├── InterviewSlotTest.java   # 18 tests — propose + confirm + cancel
    │       ├── NotificationTest.java    # 17 tests — fetch + mark read
    │       └── AdminTest.java           # 25 tests — dashboard + users + reports
    └── resources/
        ├── config.properties            # Base URL, credentials, report config
        ├── testng.xml                   # Test suite definition
        └── logback.xml                  # Logging config
```

---

## ⚙️ Prerequisites

- Java 17+
- Maven 3.8+
- TalentOS backend running (default: `http://localhost:8080`)

---

## 🚀 Quick Start

### 1. Configure

Edit `src/test/resources/config.properties`:

```properties
base.url=http://localhost:8080      # Change if your server runs elsewhere
admin.email=admin@portal.com        # Seeded by AdminSeeder.java
admin.password=admin123
```

### 2. Run all tests

```bash
mvn clean test
```

### 3. Run a specific test class

```bash
mvn clean test -Dtest=AuthTest
mvn clean test -Dtest=JobListingTest
```

### 4. Run with a different base URL

```bash
mvn clean test -Dbase.url=http://staging.talentos.com
```

---

## 📊 Extent Report

After the test run, open:

```
test-output/extent-reports/TalentOS_API_Test_Report.html
```

The report includes:
- ✅ Pass / ❌ Fail / ⚠️ Skip summary per test
- Category grouping by test class
- Request & response details for each test
- System info (base URL, Java version, OS, timestamp)

---

## 🔑 Test Execution Order

Tests are designed to run in sequence (configured via `testng.xml`):

```
AuthTest          → registers student + recruiter, stores tokens
StudentProfileTest → updates profile (required for AI matching)
ResumeTest         → uploads resume PDF
JobListingTest     → creates jobs, stores jobId
ApplicationTest    → applies for job, stores applicationId
InterviewSlotTest  → propose/confirm/cancel interview slots
NotificationTest   → read/mark notifications
AdminTest          → dashboard, user management, reports
```

Tokens and IDs flow through `TestContext` static fields.

---

## 📋 Test Coverage Summary

| Test Class           | Total | Positive | Negative |
|----------------------|-------|----------|----------|
| AuthTest             |  20   |    6     |   14     |
| StudentProfileTest   |  14   |    7     |    7     |
| ResumeTest           |   5   |    2     |    3     |
| JobListingTest       |  31   |   17     |   14     |
| ApplicationTest      |  27   |   12     |   15     |
| InterviewSlotTest    |  18   |    7     |   11     |
| NotificationTest     |  17   |   10     |    7     |
| AdminTest            |  25   |   14     |   11     |
| **Total**            | **157** | **75** | **82** |

---

## 🧪 Negative Test Scenarios Covered

- Missing required fields (400)
- Invalid enum values — `PARTTIME`, `SUPERUSER`, `PENDING` (400)
- Wrong/expired JWT token (401)
- Role-based access violations — student on recruiter endpoints (403)
- Cross-user data access — student reading another's application (403)
- Non-existent resource IDs (404)
- Duplicate application to same job (400)
- CGPA out of range `< 0` or `> 10` (400)
- File upload without file part (400/500)
- Admin-only endpoints with student/recruiter tokens (403)
