package com.talentos.constants;

public final class ApiConstants {

    private ApiConstants() {}

    // ── Auth ───────────────────────────────────────────────────────────────
    public static final String REGISTER        = "/api/v1/auth/register";
    public static final String LOGIN           = "/api/v1/auth/login";

    // ── Jobs ───────────────────────────────────────────────────────────────
    public static final String JOBS            = "/api/v1/jobs";
    public static final String JOB_BY_ID       = "/api/v1/jobs/{jobId}";
    public static final String RECRUITER_JOBS  = "/api/v1/recruiter/jobs";
    public static final String RECRUITER_JOB   = "/api/v1/recruiter/jobs/{jobId}";
    public static final String JOB_TOGGLE      = "/api/v1/recruiter/jobs/{jobId}/toggle";
    public static final String EXTRACT_SKILLS  = "/api/v1/recruiter/jobs/extract-skills";

    // ── Student Profile ────────────────────────────────────────────────────
    public static final String STUDENT_PROFILE         = "/api/v1/student/profile";
    public static final String STUDENT_PROFILE_BY_ID   = "/api/v1/student/profile/{userId}";

    // ── Resume ────────────────────────────────────────────────────────────
    public static final String RESUME_UPLOAD   = "/api/v1/student/resume/upload";

    // ── Applications ──────────────────────────────────────────────────────
    public static final String STUDENT_APPLY          = "/api/v1/student/applications/{jobId}";
    public static final String STUDENT_APPLICATIONS   = "/api/v1/student/applications";
    public static final String STUDENT_APP_BY_ID      = "/api/v1/student/applications/{applicationId}";
    public static final String STUDENT_JOB_PREVIEW    = "/api/v1/student/jobs/{jobId}/preview";
    public static final String RECRUITER_APPLICANTS   = "/api/v1/recruiter/jobs/{jobId}/applicants";
    public static final String RECRUITER_APP_BY_ID    = "/api/v1/recruiter/applications/{applicationId}";
    public static final String UPDATE_APP_STATUS      = "/api/v1/recruiter/applications/{applicationId}/status";
    public static final String RECOMPUTE_MATCH        = "/api/v1/recruiter/applications/{applicationId}/recompute-match";

    // ── Interview Slots ────────────────────────────────────────────────────
    public static final String GET_SLOT        = "/api/v1/interviews/{applicationId}";
    public static final String PROPOSE_SLOTS   = "/api/v1/recruiter/interviews/{applicationId}/propose";
    public static final String CONFIRM_SLOT    = "/api/v1/student/interviews/{applicationId}/confirm";
    public static final String CANCEL_SLOT     = "/api/v1/recruiter/interviews/{applicationId}/cancel";

    // ── Notifications ─────────────────────────────────────────────────────
    public static final String NOTIFICATIONS       = "/api/v1/notifications";
    public static final String UNREAD_COUNT        = "/api/v1/notifications/unread-count";
    public static final String MARK_READ           = "/api/v1/notifications/{notificationId}/read";
    public static final String MARK_ALL_READ       = "/api/v1/notifications/read-all";

    // ── Admin ─────────────────────────────────────────────────────────────
    public static final String ADMIN_DASHBOARD     = "/api/v1/admin/dashboard";
    public static final String ADMIN_USERS         = "/api/v1/admin/users";
    public static final String ADMIN_TOGGLE_USER   = "/api/v1/admin/users/{userId}/toggle-status";
    public static final String ADMIN_STUDENTS      = "/api/v1/admin/students";
    public static final String ADMIN_PLACEMENTS    = "/api/v1/admin/placements";
    public static final String ADMIN_PLACEMENTS_COLLEGE = "/api/v1/admin/placements/by-college";
    public static final String ADMIN_REPORT_CSV    = "/api/v1/admin/report/csv";

    // ── HTTP Status Codes ─────────────────────────────────────────────────
    public static final int OK         = 200;
    public static final int CREATED    = 201;
    public static final int BAD_REQ    = 400;
    public static final int UNAUTH     = 401;
    public static final int FORBIDDEN  = 403;
    public static final int NOT_FOUND  = 404;
    public static final int CONFLICT   = 409;

    // ── Headers ───────────────────────────────────────────────────────────
    public static final String CONTENT_TYPE  = "Content-Type";
    public static final String AUTHORIZATION = "Authorization";
    public static final String JSON          = "application/json";
}
