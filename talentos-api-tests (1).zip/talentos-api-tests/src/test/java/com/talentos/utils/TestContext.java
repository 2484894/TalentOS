package com.talentos.utils;

import java.time.Instant;

/**
 * Shared in-memory state across all test classes.
 * Tokens and IDs are populated by earlier tests.
 *
 * Emails are timestamped to be unique across multiple test runs
 * against the same database.
 */
public class TestContext {

    private TestContext() {}

    // ── Run-unique suffix (epoch seconds) ─────────────────────────────────
    // Appended to emails so repeated runs don't clash with existing DB rows.
    public static final String RUN_ID = String.valueOf(Instant.now().getEpochSecond());

    // ── Tokens ────────────────────────────────────────────────────────────
    public static volatile String studentToken   = "";
    public static volatile String recruiterToken = "";
    public static volatile String adminToken     = "";

    // ── User IDs ──────────────────────────────────────────────────────────
    public static volatile Long studentUserId   = 0L;
    public static volatile Long recruiterUserId = 0L;

    // ── Resource IDs ──────────────────────────────────────────────────────
    public static volatile Long jobId           = 0L;
    public static volatile Long applicationId   = 0L;
    public static volatile Long notificationId  = 0L;
    public static volatile Long interviewAppId  = 0L;

    // ── Dynamic credentials (built once per run) ──────────────────────────
    public static String studentEmail()    { return "student." + RUN_ID + "@test.com"; }
    public static String recruiterEmail()  { return "recruiter." + RUN_ID + "@test.com"; }
    public static String studentPassword() { return "password123"; }
    public static String recruiterPassword(){ return "password123"; }
    public static String studentName()     { return "Alice Tester"; }
    public static String recruiterName()   { return "Bob Recruiter"; }

    // ── Bearer helpers ────────────────────────────────────────────────────
    public static String bearerStudent()   { return "Bearer " + studentToken;   }
    public static String bearerRecruiter() { return "Bearer " + recruiterToken; }
    public static String bearerAdmin()     { return "Bearer " + adminToken;     }
}
