package com.talentos.utils;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class ExtentReportManager {

    private static ExtentReports extent;
    private static final ThreadLocal<ExtentTest> testThread = new ThreadLocal<>();

    private ExtentReportManager() {}

    public static synchronized ExtentReports getInstance() {
        if (extent == null) {
            String dir  = ConfigManager.getReportDir();
            String name = ConfigManager.getReportName();
            new File(dir).mkdirs();

            String reportPath = dir + File.separator + name;
            ExtentSparkReporter spark = new ExtentSparkReporter(reportPath);

            spark.config().setTheme(Theme.DARK);
            spark.config().setDocumentTitle(ConfigManager.getReportTitle());
            spark.config().setReportName(ConfigManager.getReportTitle());
            spark.config().setTimeStampFormat("dd-MM-yyyy HH:mm:ss");
            spark.config().setCss(
                ".badge-primary { background-color: #6f42c1 !important; }" +
                ".test-name { font-weight: 600; }"
            );

            extent = new ExtentReports();
            extent.attachReporter(spark);
            extent.setSystemInfo("Application",   "TalentOS Placement Portal");
            extent.setSystemInfo("Base URL",       ConfigManager.getBaseUrl());
            extent.setSystemInfo("Framework",      "REST Assured + TestNG");
            extent.setSystemInfo("Report Generated",
                LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss")));
            extent.setSystemInfo("Java Version",   System.getProperty("java.version"));
            extent.setSystemInfo("OS",             System.getProperty("os.name"));
        }
        return extent;
    }

    public static void setTest(ExtentTest test) { testThread.set(test); }
    public static ExtentTest getTest()          { return testThread.get(); }
    public static void removeTest()             { testThread.remove(); }

    public static synchronized void flush() {
        if (extent != null) extent.flush();
    }
}
