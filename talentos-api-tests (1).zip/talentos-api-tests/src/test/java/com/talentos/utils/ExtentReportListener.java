package com.talentos.utils;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

public class ExtentReportListener implements ITestListener {

    @Override
    public void onStart(ITestContext context) {
        ExtentReportManager.getInstance(); // initialise once
    }

    @Override
    public void onTestStart(ITestResult result) {
        String methodName   = result.getMethod().getMethodName();
        String testClass    = result.getTestClass().getName();
        String description  = result.getMethod().getDescription();

        ExtentTest test = ExtentReportManager.getInstance()
                .createTest(methodName, description != null ? description : "")
                .assignCategory(simpleName(testClass));
        ExtentReportManager.setTest(test);
        test.info("Test started: <b>" + methodName + "</b>");
    }

    @Override
    public void onTestSuccess(ITestResult result) {
        ExtentTest test = ExtentReportManager.getTest();
        if (test != null) {
            test.pass("✅ Test PASSED");
            logRequestResponse(test, result);
        }
        ExtentReportManager.removeTest();
    }

    @Override
    public void onTestFailure(ITestResult result) {
        ExtentTest test = ExtentReportManager.getTest();
        if (test != null) {
            test.fail("❌ Test FAILED");
            if (result.getThrowable() != null) {
                test.fail(result.getThrowable());
            }
            logRequestResponse(test, result);
        }
        ExtentReportManager.removeTest();
    }

    @Override
    public void onTestSkipped(ITestResult result) {
        ExtentTest test = ExtentReportManager.getTest();
        if (test == null) {
            test = ExtentReportManager.getInstance()
                    .createTest(result.getMethod().getMethodName())
                    .assignCategory(simpleName(result.getTestClass().getName()));
            ExtentReportManager.setTest(test);
        }
        test.skip("⚠️ Test SKIPPED");
        if (result.getThrowable() != null) test.skip(result.getThrowable());
        ExtentReportManager.removeTest();
    }

    @Override
    public void onFinish(ITestContext context) {
        ExtentReportManager.flush();
    }

    // ── Helpers ────────────────────────────────────────────────────────────

    private void logRequestResponse(ExtentTest test, ITestResult result) {
        Object[] attrs = result.getMethod().getConstructorOrMethod()
                .getMethod().getAnnotationsByType(TestInfo.class);
        // Attach any request/response stored via attribute
        Object reqLog = result.getAttribute("requestLog");
        Object resLog = result.getAttribute("responseLog");
        if (reqLog != null) test.info("<pre><b>REQUEST</b><br>" + escHtml(reqLog.toString()) + "</pre>");
        if (resLog != null) test.info("<pre><b>RESPONSE</b><br>" + escHtml(resLog.toString()) + "</pre>");
    }

    private String simpleName(String fullName) {
        return fullName.substring(fullName.lastIndexOf('.') + 1)
                .replace("Test", " Tests");
    }

    private String escHtml(String s) {
        return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;");
    }
}
