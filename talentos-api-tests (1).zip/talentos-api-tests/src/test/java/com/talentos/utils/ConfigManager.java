package com.talentos.utils;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class ConfigManager {

    private static final Properties props = new Properties();

    static {
        try (InputStream is = ConfigManager.class
                .getClassLoader().getResourceAsStream("config.properties")) {
            if (is == null) throw new RuntimeException("config.properties not found on classpath");
            props.load(is);
        } catch (IOException e) {
            throw new RuntimeException("Failed to load config.properties", e);
        }
    }

    private ConfigManager() {}

    public static String get(String key) {
        String value = System.getProperty(key, props.getProperty(key));
        if (value == null) throw new RuntimeException("Missing config key: " + key);
        return value.trim();
    }

    public static String getBaseUrl()         { return get("base.url"); }
    public static String getApiVersion()      { return get("api.version"); }
    public static String getAdminEmail()      { return get("admin.email"); }
    public static String getAdminPassword()   { return get("admin.password"); }
    public static String getStudentEmail()    { return get("student.email"); }
    public static String getStudentPassword() { return get("student.password"); }
    public static String getStudentName()     { return get("student.name"); }
    public static String getRecruiterEmail()  { return get("recruiter.email"); }
    public static String getRecruiterPassword(){ return get("recruiter.password"); }
    public static String getRecruiterName()   { return get("recruiter.name"); }
    public static String getReportDir()       { return get("report.dir"); }
    public static String getReportName()      { return get("report.name"); }
    public static String getReportTitle()     { return get("report.title"); }
}
