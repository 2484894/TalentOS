package com.talentos.tests;

import com.talentos.base.BaseTest;
import com.talentos.constants.ApiConstants;
import com.talentos.utils.TestContext;
import io.restassured.response.Response;
import org.testng.annotations.Test;

import static org.hamcrest.Matchers.*;
import static org.testng.Assert.*;

public class AuthTest extends BaseTest {

    // ═══════════════════════════════════════════════════════════════════════
    //  REGISTER – Positive
    // ═══════════════════════════════════════════════════════════════════════

    @Test(priority = 1,
          description = "[POS] Register new student — unique email per run, expects 200")
    public void registerStudent_Success() {
        Response response = withJson()
                .body(body(
                        "name",     TestContext.studentName(),
                        "email",    TestContext.studentEmail(),
                        "password", TestContext.studentPassword(),
                        "role",     "STUDENT"
                ))
                .post(ApiConstants.REGISTER);

        assertSuccess(response, ApiConstants.OK);
        response.then()
                .body("message",     equalTo("Registration successful."))
                .body("data.token",  notNullValue())
                .body("data.email",  equalTo(TestContext.studentEmail()))
                .body("data.role",   equalTo("STUDENT"))
                .body("data.userId", notNullValue());

        TestContext.studentToken  = response.jsonPath().getString("data.token");
        TestContext.studentUserId = response.jsonPath().getLong("data.userId");
        logPass("Student registered. email=" + TestContext.studentEmail()
                + " userId=" + TestContext.studentUserId);
    }

    @Test(priority = 2,
          description = "[POS] Register new recruiter — unique email per run, expects 200")
    public void registerRecruiter_Success() {
        Response response = withJson()
                .body(body(
                        "name",     TestContext.recruiterName(),
                        "email",    TestContext.recruiterEmail(),
                        "password", TestContext.recruiterPassword(),
                        "role",     "RECRUITER"
                ))
                .post(ApiConstants.REGISTER);

        assertSuccess(response, ApiConstants.OK);
        response.then()
                .body("message",    equalTo("Registration successful."))
                .body("data.role",  equalTo("RECRUITER"))
                .body("data.token", notNullValue());

        TestContext.recruiterToken  = response.jsonPath().getString("data.token");
        TestContext.recruiterUserId = response.jsonPath().getLong("data.userId");
        logPass("Recruiter registered. email=" + TestContext.recruiterEmail()
                + " userId=" + TestContext.recruiterUserId);
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  REGISTER – Negative
    // ═══════════════════════════════════════════════════════════════════════

    @Test(priority = 3, dependsOnMethods = "registerStudent_Success",
          description = "[NEG] Duplicate email — BadRequestException → 400 ApiResponse")
    public void registerStudent_DuplicateEmail() {
        Response response = withJson()
                .body(body(
                        "name",     "Duplicate",
                        "email",    TestContext.studentEmail(),   // already registered this run
                        "password", "password123",
                        "role",     "STUDENT"
                ))
                .post(ApiConstants.REGISTER);
        assertError(response, ApiConstants.BAD_REQ);
        logPass("Duplicate email rejected 400.");
    }

    @Test(priority = 4,
          description = "[NEG] Missing name — @NotBlank → 400 ApiResponse")
    public void registerStudent_MissingName() {
        Response response = withJson()
                .body(body("email", "noname@test.com", "password", "password123", "role", "STUDENT"))
                .post(ApiConstants.REGISTER);
        assertError(response, ApiConstants.BAD_REQ);
        logPass("Missing name rejected 400.");
    }

    @Test(priority = 5,
          description = "[NEG] Invalid email format — @Email → 400 ApiResponse")
    public void registerStudent_InvalidEmail() {
        Response response = withJson()
                .body(body("name", "Bad", "email", "not-valid", "password", "password123", "role", "STUDENT"))
                .post(ApiConstants.REGISTER);
        assertError(response, ApiConstants.BAD_REQ);
        logPass("Invalid email format rejected 400.");
    }

    @Test(priority = 6,
          description = "[NEG] Password < 6 chars — @Size → 400 ApiResponse")
    public void registerStudent_ShortPassword() {
        Response response = withJson()
                .body(body("name", "Short", "email", "short@test.com", "password", "abc", "role", "STUDENT"))
                .post(ApiConstants.REGISTER);
        assertError(response, ApiConstants.BAD_REQ);
        logPass("Short password rejected 400.");
    }

    @Test(priority = 7,
          description = "[NEG] Missing role — @NotNull → 400 ApiResponse")
    public void registerStudent_MissingRole() {
        Response response = withJson()
                .body(body("name", "No Role", "email", "norole@test.com", "password", "password123"))
                .post(ApiConstants.REGISTER);
        assertError(response, ApiConstants.BAD_REQ);
        logPass("Missing role rejected 400.");
    }

    @Test(priority = 8,
          description = "[NEG] Invalid role 'SUPERUSER' — Jackson deserialisation failure, status 400 or 500")
    public void registerStudent_InvalidRole() {
        Response response = withJson()
                .body(body("name", "Bad", "email", "badrole@test.com", "password", "password123", "role", "SUPERUSER"))
                .post(ApiConstants.REGISTER);
        // GlobalExceptionHandler.handleGeneral catches it as generic Exception → 500
        // OR HttpMessageNotReadableException may be caught → 400
        // Accept either as a valid error response
        assertStatusOneOf(response, 400, 500);
        logPass("Invalid role SUPERUSER rejected with " + response.statusCode() + ".");
    }

    @Test(priority = 9,
          description = "[NEG] Missing password — @NotBlank → 400 ApiResponse")
    public void registerStudent_MissingPassword() {
        Response response = withJson()
                .body(body("name", "No Pass", "email", "nopass@test.com", "role", "STUDENT"))
                .post(ApiConstants.REGISTER);
        assertError(response, ApiConstants.BAD_REQ);
        logPass("Missing password rejected 400.");
    }

    @Test(priority = 10,
          description = "[NEG] Empty body — all validations fail → 400 ApiResponse")
    public void registerStudent_EmptyBody() {
        Response response = withJson().body("{}").post(ApiConstants.REGISTER);
        assertError(response, ApiConstants.BAD_REQ);
        logPass("Empty body rejected 400.");
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  LOGIN – Positive
    // ═══════════════════════════════════════════════════════════════════════

    @Test(priority = 11, dependsOnMethods = "registerStudent_Success",
          description = "[POS] Login student — expects 200, message='Login successful.'")
    public void loginStudent_Success() {
        Response response = withJson()
                .body(body("email", TestContext.studentEmail(), "password", TestContext.studentPassword()))
                .post(ApiConstants.LOGIN);

        assertSuccess(response, ApiConstants.OK);
        response.then()
                .body("message",    equalTo("Login successful."))
                .body("data.token", notNullValue())
                .body("data.role",  equalTo("STUDENT"));

        TestContext.studentToken = response.jsonPath().getString("data.token");
        logPass("Student login ok. Token refreshed.");
    }

    @Test(priority = 12, dependsOnMethods = "registerRecruiter_Success",
          description = "[POS] Login recruiter — expects 200")
    public void loginRecruiter_Success() {
        Response response = withJson()
                .body(body("email", TestContext.recruiterEmail(), "password", TestContext.recruiterPassword()))
                .post(ApiConstants.LOGIN);

        assertSuccess(response, ApiConstants.OK);
        response.then()
                .body("data.role",  equalTo("RECRUITER"))
                .body("data.token", notNullValue());

        TestContext.recruiterToken = response.jsonPath().getString("data.token");
        logPass("Recruiter login ok. Token refreshed.");
    }

    @Test(priority = 13,
          description = "[POS] Login admin (seeded on startup) — expects 200, role=ADMIN")
    public void loginAdmin_Success() {
        Response response = withJson()
                .body(body("email", com.talentos.utils.ConfigManager.getAdminEmail(),
                           "password", com.talentos.utils.ConfigManager.getAdminPassword()))
                .post(ApiConstants.LOGIN);

        assertSuccess(response, ApiConstants.OK);
        response.then()
                .body("data.role",  equalTo("ADMIN"))
                .body("data.token", notNullValue());

        TestContext.adminToken = response.jsonPath().getString("data.token");
        logPass("Admin login ok.");
    }

    @Test(priority = 14,
          description = "[POS] Login response contains all required fields")
    public void loginStudent_ResponseStructure() {
        Response response = withJson()
                .body(body("email", TestContext.studentEmail(), "password", TestContext.studentPassword()))
                .post(ApiConstants.LOGIN);

        assertSuccess(response, ApiConstants.OK);
        response.then()
                .body("success",       equalTo(true))
                .body("message",       equalTo("Login successful."))
                .body("data.token",    notNullValue())
                .body("data.userId",   notNullValue())
                .body("data.name",     notNullValue())
                .body("data.email",    notNullValue())
                .body("data.role",     notNullValue());
        logPass("Login response structure validated.");
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  LOGIN – Negative
    // ═══════════════════════════════════════════════════════════════════════

    @Test(priority = 15,
          description = "[NEG] Wrong password — BadCredentialsException → 401 ApiResponse")
    public void loginStudent_WrongPassword() {
        Response response = withJson()
                .body(body("email", TestContext.studentEmail(), "password", "wrongpassword"))
                .post(ApiConstants.LOGIN);
        assertError(response, ApiConstants.UNAUTH);
        logPass("Wrong password rejected 401.");
    }

    @Test(priority = 16,
          description = "[NEG] Non-existent email — BadCredentialsException → 401 ApiResponse")
    public void loginStudent_NonExistentEmail() {
        Response response = withJson()
                .body(body("email", "ghost@nobody.com", "password", "password123"))
                .post(ApiConstants.LOGIN);
        assertError(response, ApiConstants.UNAUTH);
        logPass("Non-existent email rejected 401.");
    }

    @Test(priority = 17,
          description = "[NEG] Missing password — @NotBlank → 400 ApiResponse")
    public void loginStudent_MissingPassword() {
        Response response = withJson()
                .body(body("email", TestContext.studentEmail()))
                .post(ApiConstants.LOGIN);
        assertError(response, ApiConstants.BAD_REQ);
        logPass("Missing password rejected 400.");
    }

    @Test(priority = 18,
          description = "[NEG] Missing email — @NotBlank → 400 ApiResponse")
    public void loginStudent_MissingEmail() {
        Response response = withJson().body(body("password", "password123")).post(ApiConstants.LOGIN);
        assertError(response, ApiConstants.BAD_REQ);
        logPass("Missing email rejected 400.");
    }

    @Test(priority = 19,
          description = "[NEG] Empty body — validations fail → 400 ApiResponse")
    public void loginStudent_EmptyBody() {
        Response response = withJson().body("{}").post(ApiConstants.LOGIN);
        assertError(response, ApiConstants.BAD_REQ);
        logPass("Empty login body rejected 400.");
    }

    @Test(priority = 20,
          description = "[NEG] Invalid email format — @Email → 400 ApiResponse")
    public void loginStudent_InvalidEmailFormat() {
        Response response = withJson()
                .body(body("email", "not-an-email", "password", "password123"))
                .post(ApiConstants.LOGIN);
        assertError(response, ApiConstants.BAD_REQ);
        logPass("Invalid email format rejected 400.");
    }
}
