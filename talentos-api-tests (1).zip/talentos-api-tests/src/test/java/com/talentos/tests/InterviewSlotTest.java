package com.talentos.tests;

import com.talentos.base.BaseTest;
import com.talentos.constants.ApiConstants;
import com.talentos.utils.TestContext;
import io.restassured.response.Response;
import org.testng.annotations.Test;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import static org.hamcrest.Matchers.*;
import static org.testng.Assert.*;

public class InterviewSlotTest extends BaseTest {

    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");

    private String slot1() { return LocalDateTime.now().plusDays(7).withHour(10).withMinute(0).withSecond(0).format(FMT); }
    private String slot2() { return LocalDateTime.now().plusDays(8).withHour(14).withMinute(0).withSecond(0).format(FMT); }
    private String slot3() { return LocalDateTime.now().plusDays(9).withHour(11).withMinute(0).withSecond(0).format(FMT); }

    // ═══════════════════════════════════════════════════════════════════════
    //  PROPOSE SLOTS — Positive
    // ═══════════════════════════════════════════════════════════════════════

    @Test(priority = 1,
          description = "[POS] Propose 3 slots — message='Interview slots proposed.'")
    public void proposeSlots_Success() {
        Response response = withRecruiterAuth()
                .pathParam("applicationId", TestContext.interviewAppId)
                .body(body("proposedTimes", new String[]{slot1(), slot2(), slot3()}))
                .post(ApiConstants.PROPOSE_SLOTS);
        assertSuccess(response, ApiConstants.OK);
        response.then()
                .body("message",                    equalTo("Interview slots proposed."))
                .body("data.applicationId",         equalTo(TestContext.interviewAppId.intValue()))
                .body("data.proposedTimes",         hasSize(3))
                .body("data.confirmed",             equalTo(false))
                .body("data.cancelled",             equalTo(false));
        logPass("Slots proposed.");
    }

    @Test(priority = 2,
          description = "[POS] Propose single slot")
    public void proposeSlots_SingleSlot() {
        Response cr = withRecruiterAuth()
                .body(body("title", "Single Slot Job", "description", "Temp.", "jobType", "FULLTIME"))
                .post(ApiConstants.RECRUITER_JOBS);
        Long tJobId = cr.jsonPath().getLong("data.id");
        Response ar = withStudentAuth().pathParam("jobId", tJobId).post(ApiConstants.STUDENT_APPLY);
        Long tAppId = ar.jsonPath().getLong("data.id");
        Response response = withRecruiterAuth()
                .pathParam("applicationId", tAppId)
                .body(body("proposedTimes", new String[]{slot1()}))
                .post(ApiConstants.PROPOSE_SLOTS);
        assertSuccess(response, ApiConstants.OK);
        response.then().body("data.proposedTimes", hasSize(1));
        logPass("Single slot proposed.");
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  PROPOSE SLOTS — Negative
    // ═══════════════════════════════════════════════════════════════════════

    @Test(priority = 3,
          description = "[NEG] Empty proposedTimes list — @NotEmpty → 400 ApiResponse")
    public void proposeSlots_EmptyList() {
        Response response = withRecruiterAuth()
                .pathParam("applicationId", TestContext.interviewAppId)
                .body(body("proposedTimes", new String[]{}))
                .post(ApiConstants.PROPOSE_SLOTS);
        assertError(response, ApiConstants.BAD_REQ);
        logPass("Empty list rejected 400.");
    }

    @Test(priority = 4,
          description = "[NEG] Missing proposedTimes field — @NotEmpty → 400 ApiResponse")
    public void proposeSlots_MissingField() {
        Response response = withRecruiterAuth()
                .pathParam("applicationId", TestContext.interviewAppId)
                .body("{}")
                .post(ApiConstants.PROPOSE_SLOTS);
        assertError(response, ApiConstants.BAD_REQ);
        logPass("Missing proposedTimes rejected 400.");
    }

    @Test(priority = 5,
          description = "[NEG] Non-existent applicationId → 404 ApiResponse")
    public void proposeSlots_AppNotFound() {
        Response response = withRecruiterAuth()
                .pathParam("applicationId", 999999)
                .body(body("proposedTimes", new String[]{slot1()}))
                .post(ApiConstants.PROPOSE_SLOTS);
        assertError(response, ApiConstants.NOT_FOUND);
        logPass("Non-existent application → 404.");
    }

    @Test(priority = 6,
          description = "[NEG] Student proposes — Spring Security 403")
    public void proposeSlots_StudentForbidden() {
        Response response = withStudentAuth()
                .pathParam("applicationId", TestContext.interviewAppId)
                .body(body("proposedTimes", new String[]{slot1()}))
                .post(ApiConstants.PROPOSE_SLOTS);
        assertStatusCode(response, ApiConstants.FORBIDDEN);
        logPass("Student blocked 403.");
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  GET SLOT
    // ═══════════════════════════════════════════════════════════════════════

    @Test(priority = 8, dependsOnMethods = "proposeSlots_Success",
          description = "[POS] Student views slot — message='Interview slot fetched.'")
    public void getSlot_Success() {
        Response response = withStudentAuth()
                .pathParam("applicationId", TestContext.interviewAppId)
                .get(ApiConstants.GET_SLOT);
        assertSuccess(response, ApiConstants.OK);
        response.then()
                .body("message",            equalTo("Interview slot fetched."))
                .body("data.applicationId", equalTo(TestContext.interviewAppId.intValue()))
                .body("data.proposedTimes", notNullValue());
        logPass("Slot fetched by student.");
    }

    @Test(priority = 9,
          description = "[POS] Recruiter views slot — expects 200")
    public void getSlot_RecruiterCanView() {
        Response response = withRecruiterAuth()
                .pathParam("applicationId", TestContext.interviewAppId)
                .get(ApiConstants.GET_SLOT);
        assertSuccess(response, ApiConstants.OK);
        logPass("Recruiter can view slot.");
    }

    @Test(priority = 10,
          description = "[NEG] Non-existent application → 404 ApiResponse")
    public void getSlot_NotFound() {
        Response response = withStudentAuth().pathParam("applicationId", 999999).get(ApiConstants.GET_SLOT);
        assertError(response, ApiConstants.NOT_FOUND);
        logPass("Non-existent slot → 404.");
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  CONFIRM SLOT — Positive
    // ═══════════════════════════════════════════════════════════════════════

    @Test(priority = 12, dependsOnMethods = "proposeSlots_Success",
          description = "[POS] Student confirms slot — message='Interview slot confirmed.'")
    public void confirmSlot_Success() {
        // ConfirmSlotRequest.confirmedTime is a String (ISO datetime)
        Response response = withStudentAuth()
                .pathParam("applicationId", TestContext.interviewAppId)
                .body(body("confirmedTime", slot2()))
                .patch(ApiConstants.CONFIRM_SLOT);
        assertSuccess(response, ApiConstants.OK);
        response.then()
                .body("message",            equalTo("Interview slot confirmed."))
                .body("data.confirmed",     equalTo(true))
                .body("data.confirmedTime", notNullValue());
        logPass("Slot confirmed.");
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  CONFIRM SLOT — Negative
    // ═══════════════════════════════════════════════════════════════════════

    @Test(priority = 13,
          description = "[NEG] Missing confirmedTime — @NotBlank → 400 ApiResponse")
    public void confirmSlot_MissingTime() {
        Response response = withStudentAuth()
                .pathParam("applicationId", TestContext.interviewAppId)
                .body("{}")
                .patch(ApiConstants.CONFIRM_SLOT);
        assertError(response, ApiConstants.BAD_REQ);
        logPass("Missing confirmedTime rejected 400.");
    }

    @Test(priority = 14,
          description = "[NEG] Recruiter confirms — Spring Security 403")
    public void confirmSlot_RecruiterForbidden() {
        Response response = withRecruiterAuth()
                .pathParam("applicationId", TestContext.interviewAppId)
                .body(body("confirmedTime", slot1()))
                .patch(ApiConstants.CONFIRM_SLOT);
        assertStatusCode(response, ApiConstants.FORBIDDEN);
        logPass("Recruiter blocked 403.");
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  CANCEL SLOT
    // ═══════════════════════════════════════════════════════════════════════

    @Test(priority = 16,
          description = "[POS] Cancel slot — message='Interview slot cancelled.'")
    public void cancelSlot_Success() {
        Response cr = withRecruiterAuth()
                .body(body("title", "Cancel Slot Job", "description", "Temp.", "jobType", "FULLTIME"))
                .post(ApiConstants.RECRUITER_JOBS);
        Long tJobId = cr.jsonPath().getLong("data.id");
        Response ar = withStudentAuth().pathParam("jobId", tJobId).post(ApiConstants.STUDENT_APPLY);
        Long tAppId = ar.jsonPath().getLong("data.id");
        withRecruiterAuth()
                .pathParam("applicationId", tAppId)
                .body(body("proposedTimes", new String[]{slot1(), slot2()}))
                .post(ApiConstants.PROPOSE_SLOTS);
        Response response = withRecruiterAuth().pathParam("applicationId", tAppId).patch(ApiConstants.CANCEL_SLOT);
        assertSuccess(response, ApiConstants.OK);
        response.then()
                .body("message",        equalTo("Interview slot cancelled."))
                .body("data.cancelled", equalTo(true));
        logPass("Slot cancelled.");
    }

    @Test(priority = 17,
          description = "[NEG] Non-existent application → 404 ApiResponse")
    public void cancelSlot_NotFound() {
        Response response = withRecruiterAuth().pathParam("applicationId", 999999).patch(ApiConstants.CANCEL_SLOT);
        assertError(response, ApiConstants.NOT_FOUND);
        logPass("Non-existent cancel → 404.");
    }

    @Test(priority = 18,
          description = "[NEG] Student cancels — Spring Security 403")
    public void cancelSlot_StudentForbidden() {
        Response response = withStudentAuth()
                .pathParam("applicationId", TestContext.interviewAppId)
                .patch(ApiConstants.CANCEL_SLOT);
        assertStatusCode(response, ApiConstants.FORBIDDEN);
        logPass("Student blocked 403.");
    }
}
