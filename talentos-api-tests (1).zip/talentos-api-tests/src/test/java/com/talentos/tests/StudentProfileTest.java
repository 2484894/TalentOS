package com.talentos.tests;

import com.talentos.base.BaseTest;
import com.talentos.constants.ApiConstants;
import com.talentos.utils.TestContext;
import io.restassured.response.Response;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.Matchers.*;

public class StudentProfileTest extends BaseTest {

    @BeforeClass(alwaysRun = true)
    public void createStudentProfile() {
        globalSetup();
        if (TestContext.studentToken.isEmpty()) {
            logInfo("[Setup] studentToken empty — skipping profile creation.");
            return;
        }
        Response r = withStudentAuth()
                .body(body(
                        "college",       "IIT Bombay",
                        "department",    "Computer Science",
                        "batch",         "2024",
                        "cgpa",          8.5,
                        "skills",        new String[]{"Java", "Spring Boot", "Python", "React", "MySQL"},
                        "projects",      "AI placement portal using Spring Boot.",
                        "certifications","AWS Certified Cloud Practitioner",
                        "phone",         "+91-9876543210",
                        "linkedinUrl",   "https://linkedin.com/in/alice",
                        "githubUrl",     "https://github.com/alice"
                ))
                .put(ApiConstants.STUDENT_PROFILE);
        logInfo("[Setup] Profile upsert: HTTP " + r.statusCode());
    }

    @Test(priority = 1,
          description = "[POS] GET own profile — message='Profile fetched successfully.'")
    public void getMyProfile_Success() {
        Response response = withStudentAuth().get(ApiConstants.STUDENT_PROFILE);
        assertSuccess(response, ApiConstants.OK);
        response.then()
                .body("message",     equalTo("Profile fetched successfully."))
                .body("data.userId", notNullValue())
                .body("data.email",  notNullValue());
        logPass("Own profile fetched.");
    }

    @Test(priority = 2,
          description = "[POS] Student views own profile by userId (endpoint is /api/v1/student/** — STUDENT role only)")
    public void getProfileByUserId_Success() {
        Response response = withStudentAuth()
                .pathParam("userId", TestContext.studentUserId)
                .get(ApiConstants.STUDENT_PROFILE_BY_ID);
        assertSuccess(response, ApiConstants.OK);
        response.then()
                .body("message",     equalTo("Profile fetched successfully."))
                .body("data.userId", equalTo(TestContext.studentUserId.intValue()));
        logPass("Profile by userId fetched.");
    }

    @Test(priority = 3,
          description = "[POS] Student views another userId via /student/profile/{userId} — STUDENT role required")
    public void getProfileByUserId_AdminCan() {
        // /api/v1/student/** is STUDENT-role only per SecurityConfig.
        // Any authenticated student can look up any userId using this endpoint.
        Response response = withStudentAuth()
                .pathParam("userId", TestContext.studentUserId)
                .get(ApiConstants.STUDENT_PROFILE_BY_ID);
        assertSuccess(response, ApiConstants.OK);
        logPass("Student can view profile by userId.");
    }

    @Test(priority = 4,
          description = "[POS] Profile contains skills and college")
    public void getMyProfile_ContainsSkills() {
        Response response = withStudentAuth().get(ApiConstants.STUDENT_PROFILE);
        assertSuccess(response, ApiConstants.OK);
        response.then()
                .body("data.skills",     notNullValue())
                .body("data.department", equalTo("Computer Science"))
                .body("data.college",    equalTo("IIT Bombay"));
        logPass("Profile contains expected fields.");
    }

    @Test(priority = 6,
          description = "[NEG] Non-existent userId → 404 ApiResponse")
    public void getProfileByUserId_NotFound() {
        Response response = withStudentAuth()
                .pathParam("userId", 999999)
                .get(ApiConstants.STUDENT_PROFILE_BY_ID);
        assertError(response, ApiConstants.NOT_FOUND);
        logPass("Non-existent userId → 404.");
    }

    @Test(priority = 7,
          description = "[POS] Full profile update — message='Profile updated successfully.'")
    public void updateProfile_FullUpdate_Success() {
        Response response = withStudentAuth()
                .body(body(
                        "college",       "IIT Bombay",
                        "department",    "Computer Science",
                        "batch",         "2024",
                        "cgpa",          8.5,
                        "skills",        new String[]{"Java", "Spring Boot", "Python", "React", "MySQL"},
                        "projects",      "AI placement portal.",
                        "certifications","AWS Cloud Practitioner",
                        "phone",         "+91-9876543210",
                        "linkedinUrl",   "https://linkedin.com/in/alice",
                        "githubUrl",     "https://github.com/alice"
                ))
                .put(ApiConstants.STUDENT_PROFILE);

        assertSuccess(response, ApiConstants.OK);
        response.then()
                .body("message",         equalTo("Profile updated successfully."))
                .body("data.college",    equalTo("IIT Bombay"))
                .body("data.department", equalTo("Computer Science"))
                .body("data.cgpa",       equalTo(8.5f))
                .body("data.skills",     hasItem("Java"));
        logPass("Full profile update successful.");
    }

    @Test(priority = 8,
          description = "[POS] Partial update (skills only)")
    public void updateProfile_PartialUpdate_Skills() {
        Response response = withStudentAuth()
                .body(body("skills", new String[]{"JavaScript", "TypeScript", "Node.js"}))
                .put(ApiConstants.STUDENT_PROFILE);
        assertSuccess(response, ApiConstants.OK);
        withStudentAuth()
                .body(body("skills", new String[]{"Java", "Spring Boot", "Python", "React", "MySQL"}))
                .put(ApiConstants.STUDENT_PROFILE);
        logPass("Partial skills update succeeded.");
    }

    @Test(priority = 9,
          description = "[POS] CGPA boundary 10.0 accepted")
    public void updateProfile_CgpaMaxBoundary() {
        Response response = withStudentAuth().body(body("cgpa", 10.0)).put(ApiConstants.STUDENT_PROFILE);
        assertSuccess(response, ApiConstants.OK);
        response.then().body("data.cgpa", equalTo(10.0f));
        withStudentAuth().body(body("cgpa", 8.5)).put(ApiConstants.STUDENT_PROFILE);
        logPass("CGPA 10.0 accepted.");
    }

    @Test(priority = 10,
          description = "[POS] CGPA boundary 0.0 accepted")
    public void updateProfile_CgpaMinBoundary() {
        Response response = withStudentAuth().body(body("cgpa", 0.0)).put(ApiConstants.STUDENT_PROFILE);
        assertSuccess(response, ApiConstants.OK);
        response.then().body("data.cgpa", equalTo(0.0f));
        withStudentAuth().body(body("cgpa", 8.5)).put(ApiConstants.STUDENT_PROFILE);
        logPass("CGPA 0.0 accepted.");
    }

    @Test(priority = 11,
          description = "[POS] Profile completeness > 0 after update")
    public void updateProfile_CompletenessCalculated() {
        Response response = withStudentAuth().get(ApiConstants.STUDENT_PROFILE);
        assertSuccess(response, ApiConstants.OK);
        response.then()
                .body("data.profileCompletePct", notNullValue())
                .body("data.profileCompletePct", greaterThan(0));
        logPass("Profile completeness > 0.");
    }

    @Test(priority = 12,
          description = "[NEG] CGPA > 10.0 — @DecimalMax → 400 ApiResponse")
    public void updateProfile_CgpaAboveMax() {
        assertError(withStudentAuth().body(body("cgpa", 11.0)).put(ApiConstants.STUDENT_PROFILE), ApiConstants.BAD_REQ);
        logPass("CGPA > 10.0 rejected 400.");
    }

    @Test(priority = 13,
          description = "[NEG] CGPA < 0.0 — @DecimalMin → 400 ApiResponse")
    public void updateProfile_CgpaBelowMin() {
        assertError(withStudentAuth().body(body("cgpa", -1.5)).put(ApiConstants.STUDENT_PROFILE), ApiConstants.BAD_REQ);
        logPass("CGPA < 0.0 rejected 400.");
    }

    @Test(priority = 14,
          description = "[NEG] Recruiter on student endpoint — Spring Security 403")
    public void updateProfile_RecruiterForbidden() {
        assertStatusCode(withRecruiterAuth().body(body("department", "CSE")).put(ApiConstants.STUDENT_PROFILE), ApiConstants.FORBIDDEN);
        logPass("Recruiter blocked 403.");
    }
}
