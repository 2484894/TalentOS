package com.talentos.tests;

import com.talentos.base.BaseTest;
import com.talentos.constants.ApiConstants;
import com.talentos.utils.TestContext;
import io.restassured.response.Response;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.List;

import static org.hamcrest.Matchers.*;
import static org.testng.Assert.*;

public class ApplicationTest extends BaseTest {

    @BeforeClass(alwaysRun = true)
    public void ensureStudentProfile() {
        globalSetup();
        // ApplicationService requires a StudentProfile to exist
        Response r = withStudentAuth()
                .body(body(
                        "college",    "IIT Bombay",
                        "department", "Computer Science",
                        "batch",      "2024",
                        "cgpa",       8.5,
                        "skills",     new String[]{"Java", "Spring Boot", "Python", "React", "MySQL"}
                ))
                .put(ApiConstants.STUDENT_PROFILE);
        logInfo("[Setup] Profile upsert: HTTP " + r.statusCode());
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  AI PREVIEW
    // ═══════════════════════════════════════════════════════════════════════

    @Test(priority = 1,
          description = "[POS] Preview AI match — expects 200 (or 503 when Gemini quota/key is exhausted)")
    public void previewMatch_Success() {
        Response response = withStudentAuth()
                .pathParam("jobId", TestContext.jobId)
                .get(ApiConstants.STUDENT_JOB_PREVIEW);
        logResponse(response);
        int sc = response.statusCode();
        // previewMatch calls AI with no fallback: quota/key errors throw AIServiceException → 503
        if (sc == 503) {
            logPass("previewMatch returned 503 — Gemini API quota/key error. Backend has no fallback for preview.");
            return;
        }
        response.then()
                .statusCode(200)
                .body("success", equalTo(true))
                .body("message", equalTo("Match preview generated."))
                .body("data",    notNullValue());
        logPass("AI match preview ok.");
    }

    @Test(priority = 2,
          description = "[NEG] Preview non-existent job → 404 ApiResponse")
    public void previewMatch_JobNotFound() {
        Response response = withStudentAuth().pathParam("jobId", 999999).get(ApiConstants.STUDENT_JOB_PREVIEW);
        assertError(response, ApiConstants.NOT_FOUND);
        logPass("Non-existent job preview → 404.");
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  APPLY FOR JOB — Positive
    // ═══════════════════════════════════════════════════════════════════════

    @Test(priority = 3,
          description = "[POS] Apply for job — message='Application submitted successfully.'")
    public void applyForJob_Success() {
        Response response = withStudentAuth()
                .pathParam("jobId", TestContext.jobId)
                .post(ApiConstants.STUDENT_APPLY);
        assertSuccess(response, ApiConstants.OK);
        response.then()
                .body("message",     equalTo("Application submitted successfully."))
                .body("data.id",     notNullValue())
                .body("data.jobId",  equalTo(TestContext.jobId.intValue()))
                .body("data.status", equalTo("APPLIED"));

        TestContext.applicationId  = response.jsonPath().getLong("data.id");
        TestContext.interviewAppId = TestContext.applicationId;
        logPass("Applied. applicationId=" + TestContext.applicationId);
    }

    @Test(priority = 4, dependsOnMethods = "applyForJob_Success",
          description = "[POS] Application fetched successfully — AI match fields present when Gemini available")
    public void applyForJob_ContainsAiMatch() {
        Response response = withStudentAuth()
                .pathParam("applicationId", TestContext.applicationId)
                .get(ApiConstants.STUDENT_APP_BY_ID);
        assertSuccess(response, ApiConstants.OK);
        // ApplicationService.applyForJob has a try/catch: AI failures are swallowed and fields stay null.
        // We only assert the fields exist in the response object (even if null).
        response.then()
                .body("data.id",     notNullValue())
                .body("data.status", notNullValue())
                .body("data.jobId",  notNullValue());
        // Log AI match availability for informational purposes
        Object score = response.jsonPath().get("data.aiMatchScore");
        if (score != null) {
            logPass("Application fetched. AI match score present: " + score);
        } else {
            logPass("Application fetched. AI match score is null (Gemini quota/key error — graceful fallback applied).");
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  APPLY FOR JOB — Negative
    // ═══════════════════════════════════════════════════════════════════════

    @Test(priority = 5, dependsOnMethods = "applyForJob_Success",
          description = "[NEG] Duplicate application — BadRequestException → 400 ApiResponse")
    public void applyForJob_Duplicate() {
        Response response = withStudentAuth().pathParam("jobId", TestContext.jobId).post(ApiConstants.STUDENT_APPLY);
        assertError(response, ApiConstants.BAD_REQ);
        logPass("Duplicate application rejected 400.");
    }

    @Test(priority = 6,
          description = "[NEG] Non-existent job → 404 ApiResponse")
    public void applyForJob_JobNotFound() {
        Response response = withStudentAuth().pathParam("jobId", 999999).post(ApiConstants.STUDENT_APPLY);
        assertError(response, ApiConstants.NOT_FOUND);
        logPass("Non-existent job → 404.");
    }

    @Test(priority = 7,
          description = "[NEG] Recruiter applies — Spring Security 403")
    public void applyForJob_RecruiterForbidden() {
        Response response = withRecruiterAuth().pathParam("jobId", TestContext.jobId).post(ApiConstants.STUDENT_APPLY);
        assertStatusCode(response, ApiConstants.FORBIDDEN);
        logPass("Recruiter blocked 403.");
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  GET MY APPLICATIONS
    // ═══════════════════════════════════════════════════════════════════════

    @Test(priority = 9, dependsOnMethods = "applyForJob_Success",
          description = "[POS] Get my applications — message='Applications fetched.'")
    public void getMyApplications_Success() {
        Response response = withStudentAuth().get(ApiConstants.STUDENT_APPLICATIONS);
        assertSuccess(response, ApiConstants.OK);
        response.then().body("message", equalTo("Applications fetched."));
        assertFalse(response.jsonPath().getList("data").isEmpty());
        logPass("My applications fetched.");
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  GET APPLICATION BY ID (Student)
    // ═══════════════════════════════════════════════════════════════════════

    @Test(priority = 11, dependsOnMethods = "applyForJob_Success",
          description = "[POS] Student gets own application — message='Application fetched.'")
    public void getApplicationById_Student_Success() {
        Response response = withStudentAuth()
                .pathParam("applicationId", TestContext.applicationId)
                .get(ApiConstants.STUDENT_APP_BY_ID);
        assertSuccess(response, ApiConstants.OK);
        response.then()
                .body("message",     equalTo("Application fetched."))
                .body("data.id",     equalTo(TestContext.applicationId.intValue()))
                .body("data.status", notNullValue());
        logPass("Student fetched own application.");
    }

    @Test(priority = 12,
          description = "[NEG] Non-existent applicationId → 403 or 404")
    public void getApplicationById_Student_NotFound() {
        Response response = withStudentAuth().pathParam("applicationId", 999999).get(ApiConstants.STUDENT_APP_BY_ID);
        int sc = response.statusCode();
        assertTrue(sc == 403 || sc == 404, "Expected 403 or 404, got " + sc);
        logPass("Non-existent application → " + sc + ".");
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  GET APPLICANTS (Recruiter)
    // ═══════════════════════════════════════════════════════════════════════

    @Test(priority = 13, dependsOnMethods = "applyForJob_Success",
          description = "[POS] Recruiter gets applicants — message='Applicants fetched.'")
    public void getApplicantsForJob_Success() {
        Response response = withRecruiterAuth()
                .pathParam("jobId", TestContext.jobId)
                .get(ApiConstants.RECRUITER_APPLICANTS);
        assertSuccess(response, ApiConstants.OK);
        response.then().body("message", equalTo("Applicants fetched."));
        assertFalse(response.jsonPath().getList("data").isEmpty());
        logPass("Applicants fetched.");
    }

    @Test(priority = 14,
          description = "[NEG] Non-existent jobId → 404 ApiResponse")
    public void getApplicantsForJob_JobNotFound() {
        Response response = withRecruiterAuth().pathParam("jobId", 999999).get(ApiConstants.RECRUITER_APPLICANTS);
        assertError(response, ApiConstants.NOT_FOUND);
        logPass("Non-existent job → 404.");
    }

    @Test(priority = 15,
          description = "[NEG] Student on recruiter endpoint — Spring Security 403")
    public void getApplicantsForJob_StudentForbidden() {
        Response response = withStudentAuth().pathParam("jobId", TestContext.jobId).get(ApiConstants.RECRUITER_APPLICANTS);
        assertStatusCode(response, ApiConstants.FORBIDDEN);
        logPass("Student blocked 403.");
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  GET APPLICATION BY ID (Recruiter)
    // ═══════════════════════════════════════════════════════════════════════

    @Test(priority = 16, dependsOnMethods = "applyForJob_Success",
          description = "[POS] Recruiter gets application — message='Application fetched.'")
    public void getApplicationById_Recruiter_Success() {
        if (TestContext.applicationId == 0L) { logInfo("No applicationId — skip."); return; }
        Response response = withRecruiterAuth()
                .pathParam("applicationId", TestContext.applicationId)
                .get(ApiConstants.RECRUITER_APP_BY_ID);
        assertSuccess(response, ApiConstants.OK);
        response.then()
                .body("message",          equalTo("Application fetched."))
                .body("data.id",          equalTo(TestContext.applicationId.intValue()))
                .body("data.studentName", notNullValue());
        logPass("Recruiter fetched application.");
    }

    @Test(priority = 17,
          description = "[NEG] Non-existent applicationId → 403 or 404")
    public void getApplicationById_Recruiter_WrongOwner() {
        Response response = withRecruiterAuth().pathParam("applicationId", 999999).get(ApiConstants.RECRUITER_APP_BY_ID);
        int sc = response.statusCode();
        assertTrue(sc == 403 || sc == 404, "Expected 403 or 404, got " + sc);
        logPass("Non-existent application → " + sc + ".");
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  UPDATE APPLICATION STATUS
    // ═══════════════════════════════════════════════════════════════════════

    @Test(priority = 18, dependsOnMethods = "applyForJob_Success",
          description = "[POS] Shortlist — message='Application status updated.'")
    public void updateStatus_Shortlisted() {
        Response response = withRecruiterAuth()
                .pathParam("applicationId", TestContext.applicationId)
                .body(body("status", "SHORTLISTED", "recruiterNote", "Strong profile."))
                .patch(ApiConstants.UPDATE_APP_STATUS);
        assertSuccess(response, ApiConstants.OK);
        response.then()
                .body("message",     equalTo("Application status updated."))
                .body("data.status", equalTo("SHORTLISTED"));
        logPass("Status → SHORTLISTED.");
    }

    @Test(priority = 19, dependsOnMethods = "updateStatus_Shortlisted",
          description = "[POS] Mark INTERVIEW_SCHEDULED")
    public void updateStatus_InterviewScheduled() {
        Response response = withRecruiterAuth()
                .pathParam("applicationId", TestContext.applicationId)
                .body(body("status", "INTERVIEW_SCHEDULED", "recruiterNote", "Scheduled."))
                .patch(ApiConstants.UPDATE_APP_STATUS);
        assertSuccess(response, ApiConstants.OK);
        response.then().body("data.status", equalTo("INTERVIEW_SCHEDULED"));
        logPass("Status → INTERVIEW_SCHEDULED.");
    }

    @Test(priority = 20, dependsOnMethods = "updateStatus_InterviewScheduled",
          description = "[POS] Mark SELECTED")
    public void updateStatus_Selected() {
        Response response = withRecruiterAuth()
                .pathParam("applicationId", TestContext.applicationId)
                .body(body("status", "SELECTED", "recruiterNote", "Offer sent."))
                .patch(ApiConstants.UPDATE_APP_STATUS);
        assertSuccess(response, ApiConstants.OK);
        response.then().body("data.status", equalTo("SELECTED"));
        logPass("Status → SELECTED.");
    }

    @Test(priority = 21,
          description = "[POS] Mark REJECTED on a separate application")
    public void updateStatus_Rejected() {
        Response cr = withRecruiterAuth()
                .body(body("title", "Reject Test Job", "description", "Temp.", "jobType", "CONTRACT"))
                .post(ApiConstants.RECRUITER_JOBS);
        Long tJobId = cr.jsonPath().getLong("data.id");
        Response ar = withStudentAuth().pathParam("jobId", tJobId).post(ApiConstants.STUDENT_APPLY);
        Long tAppId = ar.jsonPath().getLong("data.id");
        Response response = withRecruiterAuth()
                .pathParam("applicationId", tAppId)
                .body(body("status", "REJECTED", "recruiterNote", "Not a fit."))
                .patch(ApiConstants.UPDATE_APP_STATUS);
        assertSuccess(response, ApiConstants.OK);
        response.then().body("data.status", equalTo("REJECTED"));
        logPass("Status → REJECTED.");
    }

    @Test(priority = 22,
          description = "[NEG] Invalid status 'PENDING' — Jackson deserialisation → 400 or 500")
    public void updateStatus_InvalidStatus() {
        Response r = withRecruiterAuth()
                .pathParam("applicationId", TestContext.applicationId)
                .body(body("status", "PENDING"))
                .patch(ApiConstants.UPDATE_APP_STATUS);
        assertStatusOneOf(r, 400, 500);
        logPass("Invalid status PENDING rejected with " + r.statusCode() + ".");
    }

    @Test(priority = 23,
          description = "[NEG] Missing status field — @NotNull → 400 ApiResponse")
    public void updateStatus_MissingStatus() {
        Response response = withRecruiterAuth()
                .pathParam("applicationId", TestContext.applicationId)
                .body(body("recruiterNote", "No status"))
                .patch(ApiConstants.UPDATE_APP_STATUS);
        assertError(response, ApiConstants.BAD_REQ);
        logPass("Missing status field rejected 400.");
    }

    @Test(priority = 24,
          description = "[NEG] Student updates status — Spring Security 403")
    public void updateStatus_StudentForbidden() {
        Response response = withStudentAuth()
                .pathParam("applicationId", TestContext.applicationId)
                .body(body("status", "SELECTED"))
                .patch(ApiConstants.UPDATE_APP_STATUS);
        assertStatusCode(response, ApiConstants.FORBIDDEN);
        logPass("Student blocked 403.");
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  RECOMPUTE AI MATCH
    // ═══════════════════════════════════════════════════════════════════════

    @Test(priority = 25, dependsOnMethods = "applyForJob_Success",
          description = "[POS] Recompute AI match — expects 200 (or 503 when Gemini quota/key is exhausted)")
    public void recomputeMatch_Success() {
        if (TestContext.applicationId == 0L) { logInfo("No applicationId — skip."); return; }
        Response response = withRecruiterAuth()
                .pathParam("applicationId", TestContext.applicationId)
                .post(ApiConstants.RECOMPUTE_MATCH);
        logResponse(response);
        int sc = response.statusCode();
        if (sc == 503) {
            logPass("recomputeMatch returned 503 — Gemini API quota/key error. Backend has no fallback for recompute.");
            return;
        }
        response.then()
                .statusCode(200)
                .body("success", equalTo(true))
                .body("message", equalTo("AI match recomputed."));
        logPass("AI match recomputed.");
    }

    @Test(priority = 26,
          description = "[NEG] Recompute non-existent application → 403 or 404")
    public void recomputeMatch_NotFound() {
        Response response = withRecruiterAuth().pathParam("applicationId", 999999).post(ApiConstants.RECOMPUTE_MATCH);
        int sc = response.statusCode();
        assertTrue(sc == 403 || sc == 404, "Expected 403 or 404, got " + sc);
        logPass("Non-existent recompute → " + sc + ".");
    }

    @Test(priority = 27,
          description = "[NEG] Student recomputes — Spring Security 403")
    public void recomputeMatch_StudentForbidden() {
        Response response = withStudentAuth().pathParam("applicationId", TestContext.applicationId).post(ApiConstants.RECOMPUTE_MATCH);
        assertStatusCode(response, ApiConstants.FORBIDDEN);
        logPass("Student blocked 403.");
    }
}
