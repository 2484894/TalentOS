package com.talentos.tests;

import com.talentos.base.BaseTest;
import com.talentos.constants.ApiConstants;
import com.talentos.utils.ConfigManager;
import com.talentos.utils.TestContext;
import io.restassured.response.Response;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

public class ResumeTest extends BaseTest {

    private File testPdf;

    @BeforeClass
    public void createTestFiles() throws IOException {
        testPdf = File.createTempFile("test-resume", ".pdf");
        java.nio.file.Files.write(testPdf.toPath(),
                buildPdf("Alice Johnson  Skills: Java Spring Boot Python MySQL " +
                         "Education: IIT Bombay B.Tech CSE 2024  GPA 8.5"));
    }

    @Test(priority = 1,
          description = "[POS] Upload PDF — message='Resume uploaded and parsed successfully.'")
    public void uploadResume_Success() {
        Response response = given()
                .baseUri(ConfigManager.getBaseUrl())      // ← ConfigManager, not hardcoded
                .header("Authorization", "Bearer " + TestContext.studentToken)
                .contentType("multipart/form-data")
                .multiPart("file", testPdf, "application/pdf")
                .log().all()
                .post(ApiConstants.RESUME_UPLOAD);

        logResponse(response);
        response.then()
                .statusCode(ApiConstants.OK)
                .body("success",        equalTo(true))
                .body("message",        equalTo("Resume uploaded and parsed successfully."))
                .body("data.resumeUrl", notNullValue());
        logPass("Resume uploaded.");
    }

    @Test(priority = 2, dependsOnMethods = "uploadResume_Success",
          description = "[POS] Re-upload updates resumeUrl")
    public void uploadResume_ReUpload_UpdatesUrl() {
        Response response = given()
                .baseUri(ConfigManager.getBaseUrl())
                .header("Authorization", "Bearer " + TestContext.studentToken)
                .contentType("multipart/form-data")
                .multiPart("file", testPdf, "application/pdf")
                .post(ApiConstants.RESUME_UPLOAD);
        logResponse(response);
        response.then()
                .statusCode(ApiConstants.OK)
                .body("success",        equalTo(true))
                .body("data.resumeUrl", notNullValue());
        logPass("Re-upload updated URL.");
    }

    @Test(priority = 4, description = "[NEG] Recruiter token — Spring Security 403")
    public void uploadResume_RecruiterForbidden() {
        Response response = given()
                .baseUri(ConfigManager.getBaseUrl())
                .header("Authorization", "Bearer " + TestContext.recruiterToken)
                .contentType("multipart/form-data")
                .multiPart("file", testPdf, "application/pdf")
                .post(ApiConstants.RESUME_UPLOAD);
        logResponse(response);
        assertStatusCode(response, ApiConstants.FORBIDDEN);
        logPass("Recruiter token rejected 403.");
    }

    @Test(priority = 5, description = "[NEG] No file part — expects 400 or 500")
    public void uploadResume_NoFile() {
        Response response = given()
                .baseUri(ConfigManager.getBaseUrl())
                .header("Authorization", "Bearer " + TestContext.studentToken)
                .contentType("multipart/form-data")
                .post(ApiConstants.RESUME_UPLOAD);
        logResponse(response);
        int sc = response.statusCode();
        org.testng.Assert.assertTrue(sc == 400 || sc == 500,
                "Expected 400 or 500 for no file, got " + sc);
        logPass("No file handled with status " + sc + ".");
    }

    private byte[] buildPdf(String text) {
        String safe    = text.replace("(","\\(").replace(")","\\)").replace("\n"," ");
        String content = "BT /F1 10 Tf 50 700 Td (" + safe + ") Tj ET";
        int    cLen    = content.length();
        String pdf =
            "%PDF-1.4\n1 0 obj\n<</Type/Catalog/Pages 2 0 R>>\nendobj\n" +
            "2 0 obj\n<</Type/Pages/Kids[3 0 R]/Count 1>>\nendobj\n" +
            "3 0 obj\n<</Type/Page/Parent 2 0 R/MediaBox[0 0 612 792]" +
            "/Contents 4 0 R/Resources<</Font<</F1 5 0 R>>>>>>\nendobj\n" +
            "4 0 obj\n<</Length " + cLen + ">>\nstream\n" + content + "\nendstream\nendobj\n" +
            "5 0 obj\n<</Type/Font/Subtype/Type1/BaseFont/Helvetica>>\nendobj\n" +
            "xref\n0 6\n0000000000 65535 f \n0000000009 00000 n \n" +
            "0000000058 00000 n \n0000000115 00000 n \n0000000274 00000 n \n" +
            String.format("%010d", 330 + cLen) + " 00000 n \n" +
            "trailer\n<</Size 6/Root 1 0 R>>\nstartxref\n" + (380 + cLen) + "\n%%EOF\n";
        return pdf.getBytes(java.nio.charset.StandardCharsets.ISO_8859_1);
    }
}
