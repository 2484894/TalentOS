package com.talentos.tests;

import com.talentos.base.BaseTest;
import com.talentos.constants.ApiConstants;
import com.talentos.utils.ConfigManager;
import com.talentos.utils.TestContext;
import io.restassured.response.Response;
import org.testng.annotations.Test;

import java.util.List;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;
import static org.testng.Assert.*;

public class JobListingTest extends BaseTest {

    @Test(priority = 1, description = "[POS] Create FULLTIME job — message='Job created successfully.'")
    public void createJob_WithAllFields_Success() {
        Response response = withRecruiterAuth()
                .body(body(
                        "title",            "Backend Engineer",
                        "description",      "Build scalable REST APIs with Spring Boot and PostgreSQL.",
                        "requiredSkills",   new String[]{"Java", "Spring Boot", "REST APIs", "MySQL"},
                        "niceToHaveSkills", new String[]{"Docker", "Kubernetes"},
                        "location",         "Bangalore",
                        "jobType",          "FULLTIME",
                        "ctc",              "12 LPA",
                        "minCgpa",          7.0,
                        "deadline",         "2026-12-31"
                ))
                .post(ApiConstants.RECRUITER_JOBS);

        assertSuccess(response, ApiConstants.OK);
        response.then()
                .body("message",             equalTo("Job created successfully."))
                .body("data.id",             notNullValue())
                .body("data.title",          equalTo("Backend Engineer"))
                .body("data.jobType",        equalTo("FULLTIME"))
                .body("data.active",         equalTo(true))
                .body("data.requiredSkills", hasItem("Java"));

        TestContext.jobId = response.jsonPath().getLong("data.id");
        logPass("Job created. jobId=" + TestContext.jobId);
    }

    @Test(priority = 2, description = "[POS] Create INTERNSHIP job")
    public void createJob_Internship_Success() {
        Response response = withRecruiterAuth()
                .body(body(
                        "title",          "Data Science Intern",
                        "description",    "Work with Python, pandas, TensorFlow on ML projects.",
                        "requiredSkills", new String[]{"Python", "Machine Learning", "Pandas"},
                        "location",       "Hyderabad",
                        "jobType",        "INTERNSHIP",
                        "ctc",            "25000/month",
                        "minCgpa",        7.5,
                        "deadline",       "2026-10-31"
                ))
                .post(ApiConstants.RECRUITER_JOBS);
        assertSuccess(response, ApiConstants.OK);
        response.then().body("data.jobType", equalTo("INTERNSHIP"));
        logPass("Internship job created.");
    }

    @Test(priority = 3, description = "[POS] Create job without skills — AI auto-extracts")
    public void createJob_AiAutoExtractSkills() {
        Response response = withRecruiterAuth()
                .body(body(
                        "title",       "Frontend Developer",
                        "description", "React developer with TypeScript. Redux, REST APIs, Jest testing.",
                        "location",    "Remote",
                        "jobType",     "FULLTIME",
                        "ctc",         "10 LPA",
                        "minCgpa",     6.5
                ))
                .post(ApiConstants.RECRUITER_JOBS);
        assertSuccess(response, ApiConstants.OK);
        logPass("AI skill-extraction job created.");
    }

    @Test(priority = 4, description = "[POS] Create CONTRACT job")
    public void createJob_Contract_Success() {
        Response response = withRecruiterAuth()
                .body(body(
                        "title",          "DevOps Consultant",
                        "description",    "6-month contract for cloud infra on AWS.",
                        "requiredSkills", new String[]{"AWS", "Terraform", "Docker"},
                        "location",       "Pune",
                        "jobType",        "CONTRACT"
                ))
                .post(ApiConstants.RECRUITER_JOBS);
        assertSuccess(response, ApiConstants.OK);
        response.then().body("data.jobType", equalTo("CONTRACT"));
        logPass("Contract job created.");
    }

    @Test(priority = 5, description = "[NEG] Missing title — @NotBlank → 400 ApiResponse")
    public void createJob_MissingTitle() {
        assertError(withRecruiterAuth()
                .body(body("description", "No title.", "jobType", "FULLTIME"))
                .post(ApiConstants.RECRUITER_JOBS), ApiConstants.BAD_REQ);
        logPass("Missing title rejected 400.");
    }

    @Test(priority = 6, description = "[NEG] Missing description — @NotBlank → 400 ApiResponse")
    public void createJob_MissingDescription() {
        assertError(withRecruiterAuth()
                .body(body("title", "No Desc", "jobType", "FULLTIME"))
                .post(ApiConstants.RECRUITER_JOBS), ApiConstants.BAD_REQ);
        logPass("Missing description rejected 400.");
    }

    @Test(priority = 7, description = "[NEG] Missing jobType — @NotNull → 400 ApiResponse")
    public void createJob_MissingJobType() {
        assertError(withRecruiterAuth()
                .body(body("title", "No Type", "description", "No type."))
                .post(ApiConstants.RECRUITER_JOBS), ApiConstants.BAD_REQ);
        logPass("Missing jobType rejected 400.");
    }

    @Test(priority = 8, description = "[NEG] Invalid jobType 'PARTTIME' — Jackson error → 400 or 500")
    public void createJob_InvalidJobType() {
        Response response = withRecruiterAuth()
                .body(body("title", "Wrong Type", "description", "Invalid.", "jobType", "PARTTIME"))
                .post(ApiConstants.RECRUITER_JOBS);
        assertStatusOneOf(response, 400, 500);
        logPass("Invalid jobType PARTTIME rejected with " + response.statusCode() + ".");
    }

    @Test(priority = 9, description = "[NEG] Student creates job — Spring Security 403")
    public void createJob_StudentForbidden() {
        assertStatusCode(withStudentAuth()
                .body(body("title", "Unauth", "description", "Fail", "jobType", "FULLTIME"))
                .post(ApiConstants.RECRUITER_JOBS), ApiConstants.FORBIDDEN);
        logPass("Student blocked 403.");
    }

    @Test(priority = 11, description = "[POS] Get all active jobs — message='Jobs fetched successfully.'")
    public void getAllJobs_Success() {
        Response response = withStudentAuth().get(ApiConstants.JOBS);
        assertSuccess(response, ApiConstants.OK);
        response.then()
                .body("message", equalTo("Jobs fetched successfully."))
                .body("data",    notNullValue());
        logPass("All jobs fetched.");
    }

    @Test(priority = 12, description = "[POS] Search by keyword")
    public void searchJobs_ByKeyword() {
        assertSuccess(withStudentAuth().queryParam("keyword", "Engineer").get(ApiConstants.JOBS), ApiConstants.OK);
        logPass("Keyword search ok.");
    }

    @Test(priority = 13, description = "[POS] Filter FULLTIME")
    public void filterJobs_ByTypeFULLTIME() {
        assertSuccess(withStudentAuth().queryParam("jobType", "FULLTIME").get(ApiConstants.JOBS), ApiConstants.OK);
        logPass("FULLTIME filter ok.");
    }

    @Test(priority = 14, description = "[POS] Filter INTERNSHIP")
    public void filterJobs_ByTypeINTERNSHIP() {
        assertSuccess(withStudentAuth().queryParam("jobType", "INTERNSHIP").get(ApiConstants.JOBS), ApiConstants.OK);
        logPass("INTERNSHIP filter ok.");
    }

    @Test(priority = 15, description = "[POS] Filter by minCgpa")
    public void filterJobs_ByMinCgpa() {
        assertSuccess(withStudentAuth().queryParam("minCgpa", 7.0).get(ApiConstants.JOBS), ApiConstants.OK);
        logPass("minCgpa filter ok.");
    }

    @Test(priority = 16, description = "[POS] Combined filter params")
    public void filterJobs_CombinedParams() {
        assertSuccess(withStudentAuth()
                .queryParam("keyword", "Developer")
                .queryParam("jobType", "FULLTIME")
                .queryParam("minCgpa", 6.0)
                .get(ApiConstants.JOBS), ApiConstants.OK);
        logPass("Combined params ok.");
    }

    @Test(priority = 17, dependsOnMethods = "createJob_WithAllFields_Success",
          description = "[POS] Get job by ID — message='Job fetched.'")
    public void getJobById_Success() {
        Response response = withStudentAuth().pathParam("jobId", TestContext.jobId).get(ApiConstants.JOB_BY_ID);
        assertSuccess(response, ApiConstants.OK);
        response.then()
                .body("message",    equalTo("Job fetched."))
                .body("data.id",    equalTo(TestContext.jobId.intValue()))
                .body("data.title", notNullValue());
        logPass("Get job by ID=" + TestContext.jobId + " ok.");
    }

    @Test(priority = 18, description = "[NEG] Non-existent job ID → 404 ApiResponse")
    public void getJobById_NotFound() {
        assertError(withStudentAuth().pathParam("jobId", 999999).get(ApiConstants.JOB_BY_ID), ApiConstants.NOT_FOUND);
        logPass("Non-existent ID → 404.");
    }

    @Test(priority = 20, dependsOnMethods = "createJob_WithAllFields_Success",
          description = "[POS] Recruiter gets own jobs — message='Your jobs fetched.'")
    public void getMyJobs_Success() {
        Response response = withRecruiterAuth().get(ApiConstants.RECRUITER_JOBS);
        assertSuccess(response, ApiConstants.OK);
        response.then().body("message", equalTo("Your jobs fetched."));
        assertFalse(response.jsonPath().getList("data").isEmpty());
        logPass("Recruiter jobs fetched.");
    }

    @Test(priority = 21, description = "[NEG] Student on recruiter jobs — Spring Security 403")
    public void getMyJobs_StudentForbidden() {
        assertStatusCode(withStudentAuth().get(ApiConstants.RECRUITER_JOBS), ApiConstants.FORBIDDEN);
        logPass("Student blocked 403.");
    }

    @Test(priority = 22, description = "[POS] AI extract-skills — accepts 200 or 503 (AI quota/key issues ok)")
    public void extractSkills_Success() {
        // Uses ConfigManager.getBaseUrl() — NOT hardcoded port
        Response response = given()
                .baseUri(ConfigManager.getBaseUrl())          // ← was hardcoded 8080, now fixed
                .header("Authorization", "Bearer " + TestContext.recruiterToken)
                .queryParam("jobTitle",       "DevOps Engineer")
                .queryParam("jobDescription", "Deploy Kubernetes on AWS. Jenkins CI/CD. Terraform IaC required.")
                .log().all()
                .post(ApiConstants.EXTRACT_SKILLS);

        logResponse(response);
        int sc = response.statusCode();
        // 200 = AI succeeded; 503 = AIServiceException; 500 = quota/key error caught as generic
        assertStatusOneOf(response, 200, 500, 503);
        if (sc == 200) response.then().body("success", equalTo(true));
        logPass("extract-skills returned " + sc + ".");
    }

    @Test(priority = 24, dependsOnMethods = "createJob_WithAllFields_Success",
          description = "[POS] Update job — message='Job updated successfully.'")
    public void updateJob_Success() {
        Response response = withRecruiterAuth()
                .pathParam("jobId", TestContext.jobId)
                .body(body(
                        "title",            "Senior Backend Engineer",
                        "description",      "Lead microservices team.",
                        "requiredSkills",   new String[]{"Java", "Spring Boot", "AWS"},
                        "niceToHaveSkills", new String[]{"Kafka"},
                        "location",         "Bangalore",
                        "jobType",          "FULLTIME",
                        "ctc",              "18 LPA",
                        "minCgpa",          7.5
                ))
                .put(ApiConstants.RECRUITER_JOB);
        assertSuccess(response, ApiConstants.OK);
        response.then()
                .body("message",    equalTo("Job updated successfully."))
                .body("data.title", equalTo("Senior Backend Engineer"));
        logPass("Job updated.");
    }

    @Test(priority = 25, description = "[NEG] Update non-existent job → 404 ApiResponse")
    public void updateJob_NotFound() {
        assertError(withRecruiterAuth()
                .pathParam("jobId", 999999)
                .body(body("title", "Ghost", "description", "nope", "jobType", "FULLTIME"))
                .put(ApiConstants.RECRUITER_JOB), ApiConstants.NOT_FOUND);
        logPass("Non-existent update → 404.");
    }

    @Test(priority = 26, dependsOnMethods = "createJob_WithAllFields_Success",
          description = "[POS] Toggle job inactive — message='Job status toggled.'")
    public void toggleJob_ToInactive() {
        Response response = withRecruiterAuth().pathParam("jobId", TestContext.jobId).patch(ApiConstants.JOB_TOGGLE);
        assertSuccess(response, ApiConstants.OK);
        response.then().body("message", equalTo("Job status toggled."));
        logPass("Job toggled inactive.");
    }

    @Test(priority = 27, dependsOnMethods = "toggleJob_ToInactive",
          description = "[POS] Toggle job back to active")
    public void toggleJob_ToActive() {
        Response response = withRecruiterAuth().pathParam("jobId", TestContext.jobId).patch(ApiConstants.JOB_TOGGLE);
        assertSuccess(response, ApiConstants.OK);
        response.then().body("data.active", equalTo(true));
        logPass("Job toggled active.");
    }

    @Test(priority = 28, description = "[NEG] Toggle non-existent job → 404 ApiResponse")
    public void toggleJob_NotFound() {
        assertError(withRecruiterAuth().pathParam("jobId", 999999).patch(ApiConstants.JOB_TOGGLE), ApiConstants.NOT_FOUND);
        logPass("Non-existent toggle → 404.");
    }

    @Test(priority = 29, description = "[POS] Delete own job — message='Job deleted successfully.'")
    public void deleteJob_Success() {
        Response cr = withRecruiterAuth()
                .body(body("title", "To Delete", "description", "Temp.", "jobType", "CONTRACT"))
                .post(ApiConstants.RECRUITER_JOBS);
        Long tempId = cr.jsonPath().getLong("data.id");
        Response dr = withRecruiterAuth().pathParam("jobId", tempId).delete(ApiConstants.RECRUITER_JOB);
        assertSuccess(dr, ApiConstants.OK);
        dr.then().body("message", equalTo("Job deleted successfully."));
        logPass("Job deleted. id=" + tempId);
    }

    @Test(priority = 30, description = "[NEG] Delete non-existent job → 404 ApiResponse")
    public void deleteJob_NotFound() {
        assertError(withRecruiterAuth().pathParam("jobId", 999999).delete(ApiConstants.RECRUITER_JOB), ApiConstants.NOT_FOUND);
        logPass("Delete non-existent → 404.");
    }

    @Test(priority = 31, description = "[NEG] Student deletes job — Spring Security 403")
    public void deleteJob_StudentForbidden() {
        assertStatusCode(withStudentAuth().pathParam("jobId", TestContext.jobId).delete(ApiConstants.RECRUITER_JOB), ApiConstants.FORBIDDEN);
        logPass("Student blocked 403.");
    }
}
