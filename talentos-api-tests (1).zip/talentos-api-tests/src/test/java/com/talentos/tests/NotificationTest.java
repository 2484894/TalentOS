package com.talentos.tests;

import com.talentos.base.BaseTest;
import com.talentos.constants.ApiConstants;
import com.talentos.utils.TestContext;
import io.restassured.response.Response;
import org.testng.annotations.Test;

import java.util.List;

import static org.hamcrest.Matchers.*;
import static org.testng.Assert.*;

public class NotificationTest extends BaseTest {

    // ═══════════════════════════════════════════════════════════════════════
    //  GET NOTIFICATIONS — Positive
    // ═══════════════════════════════════════════════════════════════════════

    @Test(priority = 1,
          description = "[POS] Student fetches notifications — message='Notifications fetched.'")
    public void getNotifications_Student_Success() {
        Response response = withStudentAuth().get(ApiConstants.NOTIFICATIONS);
        assertSuccess(response, ApiConstants.OK);
        response.then()
                .body("message", equalTo("Notifications fetched."))
                .body("data",    notNullValue());
        List<?> list = response.jsonPath().getList("data");
        if (!list.isEmpty()) TestContext.notificationId = response.jsonPath().getLong("data[0].id");
        logPass("Student notifications fetched. count=" + list.size());
    }

    @Test(priority = 2,
          description = "[POS] Recruiter fetches notifications — expects 200")
    public void getNotifications_Recruiter_Success() {
        Response response = withRecruiterAuth().get(ApiConstants.NOTIFICATIONS);
        assertSuccess(response, ApiConstants.OK);
        logPass("Recruiter notifications fetched.");
    }

    @Test(priority = 3,
          description = "[POS] Admin fetches notifications — expects 200")
    public void getNotifications_Admin_Success() {
        Response response = withAdminAuth().get(ApiConstants.NOTIFICATIONS);
        assertSuccess(response, ApiConstants.OK);
        logPass("Admin notifications fetched.");
    }

    @Test(priority = 4,
          description = "[POS] Notification objects contain id, message, read, createdAt")
    public void getNotifications_FieldStructure() {
        Response response = withStudentAuth().get(ApiConstants.NOTIFICATIONS);
        assertSuccess(response, ApiConstants.OK);
        List<?> list = response.jsonPath().getList("data");
        if (!list.isEmpty()) {
            response.then()
                    .body("data[0].id",        notNullValue())
                    .body("data[0].message",   notNullValue())
                    .body("data[0].read",      notNullValue())
                    .body("data[0].createdAt", notNullValue());
        }
        logPass("Field structure validated.");
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  GET NOTIFICATIONS — Negative
    // ═══════════════════════════════════════════════════════════════════════

    // ═══════════════════════════════════════════════════════════════════════
    //  UNREAD COUNT — Positive
    // ═══════════════════════════════════════════════════════════════════════

    @Test(priority = 7,
          description = "[POS] Unread count — message='Unread count fetched.'")
    public void getUnreadCount_Student_Success() {
        Response response = withStudentAuth().get(ApiConstants.UNREAD_COUNT);
        assertSuccess(response, ApiConstants.OK);
        response.then()
                .body("message",          equalTo("Unread count fetched."))
                .body("data.unreadCount", notNullValue())
                .body("data.unreadCount", greaterThanOrEqualTo(0));
        logPass("Unread count fetched.");
    }

    @Test(priority = 8,
          description = "[POS] Recruiter unread count — expects 200")
    public void getUnreadCount_Recruiter_Success() {
        Response response = withRecruiterAuth().get(ApiConstants.UNREAD_COUNT);
        assertSuccess(response, ApiConstants.OK);
        response.then().body("data.unreadCount", greaterThanOrEqualTo(0));
        logPass("Recruiter unread count fetched.");
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  UNREAD COUNT — Negative
    // ═══════════════════════════════════════════════════════════════════════

    // ═══════════════════════════════════════════════════════════════════════
    //  MARK AS READ — Positive
    // ═══════════════════════════════════════════════════════════════════════

    @Test(priority = 10, dependsOnMethods = "getNotifications_Student_Success",
          description = "[POS] Mark notification read — message='Notification marked as read.'")
    public void markAsRead_Success() {
        if (TestContext.notificationId == 0L) { logInfo("No notification — skip."); return; }
        Response response = withStudentAuth()
                .pathParam("notificationId", TestContext.notificationId)
                .patch(ApiConstants.MARK_READ);
        assertSuccess(response, ApiConstants.OK);
        response.then().body("message", equalTo("Notification marked as read."));
        logPass("Notification " + TestContext.notificationId + " marked as read.");
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  MARK AS READ — Negative
    // ═══════════════════════════════════════════════════════════════════════

    @Test(priority = 11,
          description = "[NEG] Non-existent notification → 404 ApiResponse")
    public void markAsRead_NotFound() {
        Response response = withStudentAuth().pathParam("notificationId", 999999).patch(ApiConstants.MARK_READ);
        assertError(response, ApiConstants.NOT_FOUND);
        logPass("Non-existent notification → 404.");
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  MARK ALL AS READ — Positive
    // ═══════════════════════════════════════════════════════════════════════

    @Test(priority = 13,
          description = "[POS] Student marks all read — message='All notifications marked as read.'")
    public void markAllAsRead_Student_Success() {
        Response response = withStudentAuth().patch(ApiConstants.MARK_ALL_READ);
        assertSuccess(response, ApiConstants.OK);
        response.then().body("message", equalTo("All notifications marked as read."));
        logPass("All notifications marked as read.");
    }

    @Test(priority = 14, dependsOnMethods = "markAllAsRead_Student_Success",
          description = "[POS] After mark-all-read, unread count = 0")
    public void markAllAsRead_UnreadCountZero() {
        Response response = withStudentAuth().get(ApiConstants.UNREAD_COUNT);
        assertEquals(response.jsonPath().getInt("data.unreadCount"), 0,
                "Unread count should be 0 after mark-all-read");
        logPass("Unread count is 0.");
    }

    @Test(priority = 15,
          description = "[POS] Recruiter marks all read — expects 200")
    public void markAllAsRead_Recruiter_Success() {
        Response response = withRecruiterAuth().patch(ApiConstants.MARK_ALL_READ);
        assertSuccess(response, ApiConstants.OK);
        logPass("Recruiter all notifications marked as read.");
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  MARK ALL AS READ — Negative
    // ═══════════════════════════════════════════════════════════════════════
}
