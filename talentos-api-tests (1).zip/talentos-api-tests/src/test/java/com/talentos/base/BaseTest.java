package com.talentos.base;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.talentos.utils.ConfigManager;
import com.talentos.utils.ExtentReportManager;
import com.talentos.utils.TestContext;
import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeSuite;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;
import static org.testng.Assert.*;

public abstract class BaseTest {

    protected static final Logger log = LoggerFactory.getLogger(BaseTest.class);
    protected static RequestSpecification baseSpec;

    private static volatile boolean initialized = false;

    @BeforeSuite(alwaysRun = true)
    public synchronized void globalSetup() {
        if (initialized) return;
        initialized = true;

        RestAssured.baseURI = ConfigManager.getBaseUrl();

        baseSpec = new RequestSpecBuilder()
                .setBaseUri(ConfigManager.getBaseUrl())
                .setContentType(ContentType.JSON)
                .setAccept(ContentType.JSON)
                .build();
    }

    @AfterMethod(alwaysRun = true)
    public void afterEachTest(ITestResult result) {
        ExtentTest test = ExtentReportManager.getTest();
        if (test == null) return;
        Object req = result.getAttribute("requestLog");
        Object res = result.getAttribute("responseLog");
        if (req != null) test.info("<pre><b>REQUEST:</b><br>" + esc(req.toString()) + "</pre>");
        if (res != null) test.info("<pre><b>RESPONSE:</b><br>" + esc(res.toString()) + "</pre>");
    }

    // ── Request helpers ───────────────────────────────────────────────────

    protected RequestSpecification withJson() {
        return given().spec(baseSpec).log().all();
    }

    protected RequestSpecification withAuth(String token) {
        return given().spec(baseSpec)
                .header("Authorization", "Bearer " + token)
                .log().all();
    }

    protected RequestSpecification withStudentAuth() {
        return withAuth(TestContext.studentToken);
    }

    protected RequestSpecification withRecruiterAuth() {
        return withAuth(TestContext.recruiterToken);
    }

    protected RequestSpecification withAdminAuth() {
        return withAuth(TestContext.adminToken);
    }

    // ── Assertion helpers ─────────────────────────────────────────────────

    /**
     * Asserts successful ApiResponse: HTTP status matches AND body.success == true.
     */
    protected void assertSuccess(Response response, int expectedStatus) {
        logResponse(response);
        response.then()
                .statusCode(expectedStatus)
                .body("success", equalTo(true));
    }

    /**
     * Asserts error ApiResponse from GlobalExceptionHandler (success=false in body).
     * Use ONLY when the endpoint is reached (past Spring Security) and returns ApiResponse JSON.
     */
    protected void assertError(Response response, int expectedStatus) {
        logResponse(response);
        response.then()
                .statusCode(expectedStatus)
                .body("success", equalTo(false));
    }

    /**
     * Asserts ONLY the HTTP status code — no body assertions.
     * Use for:
     *   • Spring Security 401 (no auth / invalid token) — body is empty or non-JSON
     *   • Spring Security 403 (wrong role) — body is empty or non-JSON
     *   • Any response where body format is unknown/variable
     */
    protected void assertStatusCode(Response response, int expectedStatus) {
        logResponse(response);
        assertEquals(response.statusCode(), expectedStatus,
                "Expected HTTP " + expectedStatus + " but got " + response.statusCode()
                        + "\nBody: " + safeBody(response));
    }

    /**
     * Asserts HTTP 400 only (no body assertion).
     * Use when Jackson enum deserialisation may return 400 with Spring's own format
     * rather than our ApiResponse.
     */
    protected void assert400(Response response) {
        logResponse(response);
        assertEquals(response.statusCode(), 400,
                "Expected HTTP 400 but got " + response.statusCode()
                        + "\nBody: " + safeBody(response));
    }

    /**
     * Asserts HTTP status is one of the acceptable codes (use for endpoints
     * that may return different valid codes depending on AI availability or state).
     */
    protected void assertStatusOneOf(Response response, int... acceptableCodes) {
        logResponse(response);
        int actual = response.statusCode();
        for (int code : acceptableCodes) {
            if (actual == code) return;
        }
        StringBuilder sb = new StringBuilder("Expected one of [");
        for (int i = 0; i < acceptableCodes.length; i++) {
            if (i > 0) sb.append(", ");
            sb.append(acceptableCodes[i]);
        }
        sb.append("] but got ").append(actual).append("\nBody: ").append(safeBody(response));
        fail(sb.toString());
    }

    protected void logResponse(Response response) {
        // Extract body FIRST before any streaming operations consume it
        String body = safeBody(response);
        int    sc   = response.statusCode();

        try { response.then().log().all(); } catch (Exception ignored) {}

        ExtentTest test = ExtentReportManager.getTest();
        if (test != null) {
            test.log(Status.INFO,
                    "<pre>HTTP " + sc + "<br>" + esc(body) + "</pre>");
        }
    }

    protected void logInfo(String message) {
        log.info(message);
        ExtentTest test = ExtentReportManager.getTest();
        if (test != null) test.info(message);
    }

    protected void logPass(String message) {
        log.info("PASS: " + message);
        ExtentTest test = ExtentReportManager.getTest();
        if (test != null) test.pass(message);
    }

    // ── Body builder ──────────────────────────────────────────────────────

    protected java.util.Map<String, Object> body(Object... kvPairs) {
        if (kvPairs.length % 2 != 0)
            throw new IllegalArgumentException("key-value pairs must be even");
        java.util.Map<String, Object> map = new java.util.LinkedHashMap<>();
        for (int i = 0; i < kvPairs.length; i += 2)
            map.put((String) kvPairs[i], kvPairs[i + 1]);
        return map;
    }

    // ── Safe body extraction ──────────────────────────────────────────────

    /**
     * Safely extracts response body as string without throwing.
     * RestAssured can sometimes throw on non-JSON responses.
     */
    protected String safeBody(Response response) {
        try {
            return response.getBody().asString();
        } catch (Exception e) {
            return "(could not extract body: " + e.getMessage() + ")";
        }
    }

    private String esc(String s) {
        return s == null ? "" : s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;");
    }
}
